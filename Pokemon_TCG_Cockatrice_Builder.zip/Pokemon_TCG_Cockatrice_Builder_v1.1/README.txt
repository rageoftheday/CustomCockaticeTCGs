POKEMON TCG -> COCKATRICE XML BUILDER v1 (Windows PowerShell 5.1+)
========================================================================
1. Extract the entire ZIP to a normal writable folder.
2. Double-click 0-Update-Pokemon.bat.
3. The first full run retrieves English card DETAILS one at a time. It can be lengthy.
   It stores JSON under Cache and can resume after an interrupted or failed run.
4. After validating it, the installer offers detected Cockatrice customsets locations,
   a manual folder browser, or "S" to save XML only to Output.
5. Restart Cockatrice, then Card Database > Manage Sets to enable the new sets.

WHAT IT DOES
- Uses English card game text and English name for EVERY exported definition.
- Adds image URL variants for matching card IDs in available TCGdex languages.
- Does NOT download or bundle images; Cockatrice downloads/caches images when needed.
- Groups mechanically equivalent English cards into one XML card with many <set>
  printings. Different HP/attacks/effects remain distinct.
- Prefixes names PKM: and includes a reference ID to avoid collisions with existing
  Magic cards, and to distinguish same-name cards with different mechanics.
- Creates expansion+language sets with codes like PKENxxxxxxxxx.
- Writes 01.PokemonTCG.xml only in the chosen CUSTOM SETS folder.
- Never overwrites Cockatrice's normal cards.xml or your Magic updater data.
- Keeps logs, cached API JSON, and backups of prior Pokemon XML versions.
- If any English card detail fails, aborts BEFORE replacing the existing XML.

EXAMPLES
  powershell -NoProfile -ExecutionPolicy Bypass -File .\Update-Pokemon.ps1 -MaxCards 30 -BuildOnly
  powershell -NoProfile -ExecutionPolicy Bypass -File .\Update-Pokemon.ps1 -ArtLanguages English -BuildOnly
  powershell -NoProfile -ExecutionPolicy Bypass -File .\Update-Pokemon.ps1 -CustomSetsPath "D:\Cockatrice\data\customsets"

NOTE: -MaxCards is strictly a SMALL TEST subset. Do not use it when updating a
full installation: it would replace the full Pokemon XML with only the subset.

CUSTOM SET LOCATION
Use Cockatrice: Card Database > Open custom sets folder.
The app may have a custom data-directory setting. This updater asks instead of
assuming that Program Files is the right location. The chosen location is saved
in pokemon-location.txt. If you have multiple installations, select carefully.

LIMITATIONS
- TCGdex currently has incomplete language/image coverage; unavailable art is skipped.
- Only cards with English source details are exported. Cards without an English
  equivalent are reported by absence, not incorrectly given invented wording.
- Artwork is grouped by shared TCGdex IDs. Distinct card IDs are not inferred to
  be identical purely from their translated name.
- Card mechanics and English wording are as complete as TCGdex's English data.
- Pokemon play zones and rules are NOT added to Cockatrice.
- A first full download can require thousands of API calls. Avoid running
  repeatedly with -RefreshCache; it deliberately re-fetches everything.
- File validation is structural XML validation; detailed schema validation is
  a separate recommended check with Cockatrice's cards.xsd.
- The installer/backups do NOT automatically roll back the user's Cockatrice
  customsets selection or modified settings.

SOURCE / DOCUMENTATION
https://tcgdex.dev/
https://cockatrice.github.io/docs/dc/d4d/custom_card_pictures.html
https://github.com/Cockatrice/Cockatrice/wiki/Custom-Cards-%26-Sets

v1.1 FIX (November 2026)
------------------------
- Handles null/empty responses from sparsely populated TCGdex languages without
  trying to Move-Item a missing .json.new cache file.
- Skips languages that return no published card records.
- Retains already cached English/French/Spanish/etc indexes and card details.
- Safe to extract this version over v1; keep the Cache directory if you have one.
- A language warning does not invalidate the build unless English fails.

@echo off
setlocal
set "P=%~dp0Logs\missing-artwork-review.html"
if not exist "%P%" (
  echo No review file yet. Run 0-Update-Pokemon.bat first.
  pause
  exit /b 1
)
start "" "%P%"

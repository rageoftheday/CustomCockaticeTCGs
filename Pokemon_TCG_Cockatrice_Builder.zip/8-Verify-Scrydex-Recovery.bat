@echo off
setlocal
cd /d "%~dp0"
echo ==========================================================
echo  POKEMON - SCRYDEX LINK RECOVERY - 277 CANDIDATES
 echo ==========================================================
echo Only image URLs confirmed by a live download will be added.
echo This does not overwrite your existing XML or override CSV.
echo.
set "PY_CMD=py -3"
py -3 --version >nul 2>&1
if errorlevel 1 (
  python --version >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python 3 required for this optional artwork verification.
    echo Install Python 3, or use an existing Python 3 installation.
    pause
    exit /b 1
  )
  set "PY_CMD=python"
)
%PY_CMD% "check_and_apply_scrydex_358.py" --candidates "Pokemon_358_Scrydex_Link_Candidates.csv" --xml "01.PokemonTCG_Link_Candidates_Plus_2.xml" --out "Scrydex-Verified-Results"
if errorlevel 1 (
 echo Verification stopped with an error. Read the message above.
 pause
 exit /b 1
)
echo.
echo Finished. To preserve recovered images during future updates, merge
 echo Scrydex-Verified-Results\image-overrides-verified-only.csv into
 echo your main image-overrides.csv (TCGdexId,ImageUrl; no duplicate IDs).
echo.
pause

v2.2: STRICT DEFAULT / OPTIONAL VISUAL PLACEHOLDERS

0-Update-Pokemon.bat retains strict matching: exact English printing or identical full rules only.
6-Build-With-Visual-Placeholders.bat additionally uses card art from a different printing with the same English name and category when no strict image is available.
WARNING: Substitute pictures can show incorrect HP, attacks or rules. Cockatrice XML text remains original and accurate. This is only a visual preference.
Check Logs\same-name-visual-placeholders.csv to identify all substitutions. No printing is deleted.
The 2026 Delta Reign and Pocket Paldean Wonders gaps cannot reliably be supplied by the historical PokemonTCG GitHub archive. Bulbagarden Archives specifically forbids direct-linking images to external sites; the updater does not hotlink their image CDN.

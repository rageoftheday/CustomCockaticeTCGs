@echo off
setlocal
cd /d "%~dp0"
echo This will re-enable artwork providers disabled after API errors.
echo Existing card details, images and image overrides will NOT be deleted.
choice /C YN /N /M "Reset disabled artwork sources? [Y/N] "
if errorlevel 2 exit /b 0
if exist "Cache\artwork-disabled-sources.json" (
  del /q "Cache\artwork-disabled-sources.json"
  if errorlevel 1 (echo ERROR: Could not delete disable list.) else (echo Reset complete. Providers will be tried on the next update.)
) else (echo No providers are currently disabled.)
pause

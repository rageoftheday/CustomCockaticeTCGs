Pokémon Cockatrice Builder v1.5 — artwork fallback

ENGLISH-ONLY. Keep your existing Cache folder. Copy these scripts over the old versions.

Artwork resolution, in order:
1. Exact English printing image in the TCGdex catalog or card-detail cache.
2. image-overrides.csv direct HTTPS artwork URL for exact TCGdexId (manual/authorized image links).
3. Legacy Pokémon TCG API (api.pokemontcg.io): one exact-name/collector-number/set-name match, using its images.large URL. Never substitute a similarly named printing from another set.
4. Leave picurl blank and report the card ID if no safe match exists.

TCGplayer does not offer a public unauthenticated image lookup API. A TCGplayer product PAGE URL is not a direct image URL. If you have authorized use of a direct image URL from TCGplayer or elsewhere, add the exact TCGdex ID and that HTTPS image URL as one row of image-overrides.csv. These overrides are not tested for hosting/permission/reliability by the script.

Usage: 0-Update-Pokemon.bat (normal update)
Custom PowerShell options: -FallbackMaxLookups 120 (default 120 NEW alternate-source queries per run); -FallbackMaxLookups 0 (unlimited, rate limited to about 27/minute); -SkipSecondaryArtwork (use TCGdex and manual overrides only).

Secondary artwork results are kept in Cache/art-pokemontcg-*.json. Successful matches are reused indefinitely; negative matches refresh after 14 days. Network/rate errors are NOT cached. The English card caches are unchanged. The updater keeps safe XML backups and reports missing image IDs in Logs/missing-English-artwork-ids.txt.

NOTE: Pokémon TCG API v2 is being deprecated and is scheduled to shut down on 2027-03-01. Fallback images already indexed in the cache use stable legacy image URLs, which may eventually cease to resolve; they are not downloaded here. Existing TCGdex images remain the preferred source.

# Pokémon Cockatrice Builder v2.5 — all 23,912 printings have a URL (candidate mode)

Run **0-Update-Pokemon.bat** to rebuild and install as usual. The standard update now applies `artwork-printing-overrides.csv` automatically **after generating the XML but before validation and installation**. It only fills blank `picurl` values and never overwrites existing URLs. Correct printing rows are matched using card name, Cockatrice set code, card number, and duplicate-row occurrence. All records, mechanics and set assignments remain untouched.

The supplied prebuilt file `01.PokemonTCG_100pct_URLs_CANDIDATES.xml` has **23,912/23,912 nonempty HTTPS image URLs**, 18,484 cards and 217 sets. This is **100% URL presence, NOT 100% working or correct exact-printing scans**. The prebuilt file contains many unverified external links and 106 visual substitutions (83 borrowing from a different printing of the same grouped card ID; 23 from the same card name). Some candidate direct links are seller images and may disappear. An image URL can return a page or fail on Cockatrice despite being populated.

`artwork-coverage-report.csv` lists all 775 printings missing in the original strict XML; includes each exact printing, URL, source and method. Filter Method = `same-card-id-visual-substitute` or `same-name-visual-substitute` to inspect 106 deliberate fallback images.

`Logs\v2.5-artwork-applied.csv` records newly filled printing rows after your Windows updater runs. Use **7-Audit-Image-Links.bat** to test the image servers; note that the existing audit script may sample a limited number of URLs. Keep the report when testing in Cockatrice.

If you need guaranteed 100% exact artwork, the image candidates must be HTTP-checked and compared visually. This package does not claim that was done.

The v2.5 overlay is tied to the current output's card grouping. If upstream grouping changes or new cards appear, `0-Update-Pokemon.bat` logs how many blank rows remain; it never guesses a match.

﻿param([string]$XmlPath = '', [string]$OverrideFile = '')
$ErrorActionPreference='Stop'
$Base=Split-Path -Parent $MyInvocation.MyCommand.Path
if(-not $XmlPath){$XmlPath=Join-Path $Base 'Output\01.PokemonTCG.xml'}
if(-not $OverrideFile){$OverrideFile=Join-Path $Base 'artwork-printing-overrides.csv'}
if(-not (Test-Path -LiteralPath $XmlPath)){throw "Missing XML: $XmlPath"}
$rows=@(Import-Csv -LiteralPath $OverrideFile -Encoding UTF8)
$map=@{}
foreach($r in $rows){$key=$r.CardName+'|'+$r.SetCode+'|'+$r.SetNumber+'|'+$r.Occurrence;$map[$key]=$r}
$d=New-Object Xml.XmlDocument;$d.PreserveWhitespace=$true;$d.Load($XmlPath)
$added=0
foreach($card in $d.SelectNodes('/cockatrice_carddatabase/cards/card')){
 $name=$card.SelectSingleNode('name').InnerText;$seen=@{}
 foreach($p in $card.SelectNodes('set')){
  $sc=$p.InnerText.Trim();$n=$p.GetAttribute('num');$part=$sc+'|'+$n
  if(-not $seen.ContainsKey($part)){$seen[$part]=0};$seen[$part]++
  $key=$name+'|'+$sc+'|'+$n+'|'+$seen[$part]
  if(-not $p.GetAttribute('picurl') -and $map.ContainsKey($key)){
   $u=([string]$map[$key].ImageUrl).Trim()
   if($u.StartsWith('https://')){[void]$p.SetAttribute('picurl',$u);$added++}
  }
 }
}
$blank=$d.SelectNodes('/cockatrice_carddatabase/cards/card/set[not(@picurl) or @picurl=""]').Count
$backup=$XmlPath+'.before-v25.bak';Copy-Item -LiteralPath $XmlPath -Destination $backup -Force
$d.Save($XmlPath)
Write-Host "Added $added; still without links: $blank; backup $backup"

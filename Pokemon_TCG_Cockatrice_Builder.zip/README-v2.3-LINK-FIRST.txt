Pokemon Cockatrice Builder v2.3 - LINK-FIRST + SAFE IMAGE AUDIT

0-Update-Pokemon.bat: strict original behavior. TCGdex first, then exact matched legacy archive, cached secondary lookups, and exact-rules borrowed artwork. Does not overwrite existing found artwork URLs and does not auto-scrape sites.
6-Build-With-Visual-Placeholders.bat: optional SAME-NAME art (possibly different card rules). Keep OFF for exact images.
7-Audit-Image-Links.bat: check up to 150 unique hosted URLs via HTTP HEAD, with 10-second timeout and persistent report cache. Opens no images and never edits XML. Results: OK-IMAGE, MISSING, BLOCKED-OR-HEAD-UNSUPPORTED, CHECK-CONTENT-TYPE, RETRY-LATER. HEAD blocked does not mean missing. Output: Logs\image-link-audit.csv.
Use: powershell -NoProfile -ExecutionPolicy Bypass -File .\Audit-Pokemon-Image-Links.ps1 -MaxUrls 300 -OnlyUnique -Recheck

Logs\missing-artwork-review.html and .csv now include discovery links for PkmnCards, Limitless, Bulbapedia, the official Pokemon card database, and TCGdex. They are SEARCH/REVIEW URLs, NOT verified downloadable image links. Verify exact printing and site's direct-linking rules before writing an override in image-overrides.csv.

The bundled preloaded card details remain cached. In this version no scraped copyrighted card images are downloaded or rehosted.
Only static checks were possible here; run BATs on Windows to validate network behavior.

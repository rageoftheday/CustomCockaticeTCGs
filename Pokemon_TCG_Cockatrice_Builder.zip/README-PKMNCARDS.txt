POKEMON BUILDER v1.7 - PKMNCARDS ARTWORK REVIEW
==================================================

PkmnCards is an English scan/reference database, but does not offer a public
card-data API and restricts automated traffic that burdens the website.
This version DOES NOT scrape pages, bulk download images, or hotlink new
images automatically from PkmnCards. Instead it generates:
  Logs\missing-artwork-review.html (clickable PkmnCards + web searches)
  Logs\missing-artwork-review.csv  (Excel-friendly exact-printing queue)

Once the normal English-only build finishes, run
  4-Open-Missing-Artwork-Review.bat
Use name, set AND number together to verify exact art. If you are authorized
to use a DIRECT image URL, paste the TCGdex ID and full HTTPS image URL in
  image-overrides.csv
(columns TCGdexId,ImageUrl). Example (placeholder, not a real image):
  TCGdexId,ImageUrl
  mee-009,https://your-approved-image-host.example/mee-009.png

Product pages such as tcgplayer.com/product/... are not direct image links.
An exact-image URL needs to end in .jpg, .jpeg, .png or .webp.

The regular sources remain TCGdex and the cached PokemonTCG.io API fallback.
Transient 500/502/503 requests trigger the circuit breaker, not permanent
negative cache records. Progress counters remain active throughout the run.

INSTALL: Replace the .ps1/.bat scripts in your existing builder folder.
KEEP Cache, image-overrides.csv, and pokemon-location.txt.
Never overwrite the user's populated cache with this empty starter package.

NOTES: Static validation and ZIP packaging performed on Linux; Windows
PowerShell 5.1 end-to-end build could not be executed here.

NEUROSCAPE GENESIS -> COCKATRICE (NSCP)
====================================

1. Run PowerShell as your normal Windows user.
2. In the folder containing the PS1, run:
     powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\Build-Neuroscape-Cockatrice.ps1"

   Or to copy generated files to the usual Windows Cockatrice folders:
     powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\Build-Neuroscape-Cockatrice.ps1" -Install

3. The script may use winget to install ImageMagick, needed because source card images are in WebP format. If you prefer to install it yourself:
     winget install --id ImageMagick.ImageMagick -e
   Then close and reopen PowerShell. A genuine JPEG is created for every downloaded image.

4. Output defaults to Downloads\Neuroscape_Cockatrice:
   - 01.NeuroScape_Genesis.xml : Cockatrice v4 custom set
   - Images_JPG\              : numbered Cockatrice-compatible JPG artwork
   - Source_WebP\             : original downloaded images (backup)
   - Neuroscape_Card_Report.csv: full card/art/image status report
   - Neuroscape_Errors.txt    : anything not downloaded or parsed

5. Manual installation:
   In Cockatrice, use Card Database > Open custom sets folder.
   Copy 01.NeuroScape_Genesis.xml into that folder.
   In Cockatrice, use Card Database > Open custom image folder.
   Copy the Images_JPG pictures there (a subfolder is fine).
   Restart Cockatrice, enable NSCP if asked, and check a few images.

6. If you previously ran the script, existing JPGs are preserved.
   The -Install option uses usual default Windows Cockatrice folders; if
   your Cockatrice uses other folders, use the menus mentioned above.

NOTES:
- The data comes from Deckscape's community NeuroScape card directory, not an official structured export.
- The gallery currently lists 256 printings. If the website changes structure,
  this script reports errors rather than inventing card data.
- Cockatrice is a tabletop card manager and will not enforce NeuroScape rules.
- The XML has the complete card list it successfully fetches, with RAM as mana cost
  and character attack/defence as power/toughness. Effects require player handling.
- Art and card content are owned by NeuroScape / their respective rights holders;
  use for private play and avoid redistributing the art without permission.

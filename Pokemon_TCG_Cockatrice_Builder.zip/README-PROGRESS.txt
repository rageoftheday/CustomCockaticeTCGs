Pokemon TCG Cockatrice Builder v1.6 - Progress and API timeout hotfix

Copy the v1.6 scripts OVER your existing builder scripts, NOT over Cache.
Your existing Cache, image-overrides.csv, Logs, output and installed XML are retained.

New console/log indicators:
- CARDS [####------] XX% (processed/total) every 100 card details
- ARTWORK [####------] XX% (checked/total) every 25 missing printings
- Before EACH external fallback API call: card ID, request count and timeout
- XML [####------] XX% every 1,000 entries
- Final XML validation and install status as before.

The percent is stage-local, rather than an estimated time-to-complete.

New PowerShell optional settings:
-FallbackTimeoutSec 12 (per-request timeout, seconds; default 12)
-FallbackCircuitLimit 3 (stop calling legacy image API after 3 consecutive errors; default 3)
-FallbackMaxLookups 120 (existing per-run query cap)
-SkipSecondaryArtwork (existing: don't call legacy API)

Examples:
0-Update-Pokemon.bat
0-Update-Pokemon.bat -SkipSecondaryArtwork
0-Update-Pokemon.bat -FallbackMaxLookups 30 -FallbackTimeoutSec 8

IMPORTANT: Circuit breaker applies only to the current run. It doesn't delete
or permanently blacklist any cards. Existing successful and negative-cache results
are reused, and server errors are never cached as negative matches.

A full Windows PowerShell 5.1 execution has NOT been performed here.

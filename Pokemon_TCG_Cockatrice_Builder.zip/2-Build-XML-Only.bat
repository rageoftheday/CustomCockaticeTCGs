@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-Pokemon.ps1" -ArtLanguages English -BuildOnly
pause

# Optional cache cleanup. Never deletes English caches or card detail files.
$ErrorActionPreference = 'Stop'
$cache = Join-Path $PSScriptRoot 'Cache'
if (-not (Test-Path -LiteralPath $cache -PathType Container)) { Write-Host 'No Cache folder found.'; exit 0 }
$all = @(Get-ChildItem -LiteralPath $cache -File)
$foreign = @($all | Where-Object {
    $_.Name -match '^index-(sets|cards)-(.+)\.json$' -and
    $Matches[2] -ne 'en'
})
Write-Host ('Foreign-language index cache files found: ' + $foreign.Count)
Write-Host 'English index-sets-en.json, index-cards-en.json and en-card-*.json are protected.'
if ($foreign.Count -eq 0) { exit 0 }
$answer=Read-Host 'Type DELETE to remove only these non-English index cache files'
if ($answer -cne 'DELETE') { Write-Host 'Canceled. Nothing deleted.'; exit 0 }
foreach ($f in $foreign) { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop; Write-Host ('Removed: ' + $f.Name) }
Write-Host 'Done. English cache preserved.'

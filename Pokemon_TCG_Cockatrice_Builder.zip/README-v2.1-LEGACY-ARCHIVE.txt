POKEMON COCKATRICE UPDATER v2.1 - EXACT ENGLISH ARTWORK RECOVERY

What's new:
* Adds an image fallback to the public PokemonTCG/pokemon-tcg-data repository's historical English card catalog, accessed using raw.githubusercontent.com.
* Matches an existing historical image record only when its English set name, card name, and collector number all match. No invented CDN paths and no name-only substitution.
* Fetches at most 30 NEW catalog files per run by default (including the index), prioritizing sets with the most missing images. Catalog JSON is saved in Cache/art-legacy-*.json. Cached data is reused without live requests.
* 404 for an absent catalog is cached for 30 days, not treated as a provider outage.
* Provider/network/5xx/429 errors quarantine raw.githubusercontent.com persistently, like the existing API quarantine. Neither source being disabled prevents cached artwork from being used.
* Leaves manual overrides, exact TCGdex URLs, previous cache, two-pass safe borrow, card text, sets and card IDs intact.
* Logs/legacy-github-artwork-recovered.csv identifies each recovery and its exact matched fields.

RUN: 0-Update-Pokemon.bat
OPTIONS: For a full catalog sweep, use 0-Update-Pokemon.bat -LegacySetMaxDownloads 100
         To work offline or skip the source, use -SkipLegacyGitHub
         Default setting 30 avoids unnecessarily many external requests.
         You can still set -FallbackMaxLookups 0 for the legacy live API, but that source may be disabled.
         5-Reset-Disabled-Artwork-Sources.bat re-enables quarantined providers when you choose.

IMPORTANT: The upstream PokemonTCG data repository is legacy. It documents that the API is set to shut down in March 2027. Local caches are retained. Static data is not a guarantee that its image URLs will remain online. URLs are NOT claimed to have been HTTP-validated. Network source and full Windows PowerShell execution could not be tested in the isolated build environment.

Source: https://github.com/PokemonTCG/pokemon-tcg-data
Source set index: https://raw.githubusercontent.com/PokemonTCG/pokemon-tcg-data/master/sets/en.json
Source set card pattern: https://raw.githubusercontent.com/PokemonTCG/pokemon-tcg-data/master/cards/en/{validated-legacy-set-id}.json

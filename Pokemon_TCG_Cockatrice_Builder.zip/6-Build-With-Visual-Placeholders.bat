@echo off
setlocal
cd /d "%~dp0"
echo WARNING: Same-name card art may show DIFFERENT HP, attacks, abilities or effects.
echo Printed artwork is VISUAL PLACEHOLDER ONLY; the Cockatrice text is authoritative.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-Pokemon.ps1" -AllowSameNameVisualFallback
pause

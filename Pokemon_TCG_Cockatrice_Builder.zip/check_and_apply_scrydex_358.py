#!/usr/bin/env python3
"""Verify Scrydex candidate images and write ONLY successful Cockatrice picurl overrides.
No API credentials required. Not a scraper: requests direct card artwork URLs.
"""
import argparse,csv,io,pathlib,re,sys,time,urllib.request,urllib.error,xml.etree.ElementTree as ET,collections

F=['TCGdexId','CardName','EnglishSet','CollectorNumber','ScrydexId','CandidateImageUrl','ScrydexSearch','Status','Evidence']

def image_magic(b):
    return (b.startswith(b'\x89PNG\r\n\x1a\n') or b.startswith(b'\xff\xd8\xff') or (b.startswith(b'RIFF') and b[8:12]==b'WEBP'))

def verify(url,timeout=13):
    req=urllib.request.Request(url,headers={'User-Agent':'Cockatrice-Pokemon-Link-Audit/1.0 (personal client image validation)','Accept':'image/png,image/jpeg,image/webp,*/*','Range':'bytes=0-32767'})
    try:
        with urllib.request.urlopen(req,timeout=timeout) as f:
            status=getattr(f,'status',200); content=f.read(32768); typ=f.headers.get('Content-Type','').split(';')[0].strip().lower()
            if status not in (200,206): return 'HTTP_'+str(status),str(status)
            if not image_magic(content): return 'NOT_IMAGE',typ or 'unknown'
            if typ and not typ.startswith('image/'): return 'WRONG_CONTENT_TYPE',typ
            return 'OK_IMAGE',str(status)
    except urllib.error.HTTPError as e:return 'HTTP_'+str(e.code),str(e.code)
    except Exception as e:return 'ERROR',str(e)[:180]

def process(candidates,xml_path,outdir,check_fn=verify,delay=0.15):
    outdir.mkdir(parents=True,exist_ok=True)
    if (outdir/'01.PokemonTCG.scrydex-verified.xml').exists():
        raise SystemExit('Output XML already exists. Choose a new output folder to avoid overwriting data.')
    tree=ET.parse(xml_path)
    root=tree.getroot()
    cards={}
    for c in root.findall('./cards/card'):
        m=re.search(r'\[([^\]]+)\]$',c.findtext('name',''))
        if m: cards.setdefault(m.group(1).lower(),[]).append(c)
    audit=[]; overrides=[]; used=set()
    for i,r in enumerate(candidates,1):
        id=r['TCGdexId'].strip().lower(); url=r['CandidateImageUrl'].strip()
        if id in used: raise ValueError('Duplicate candidate ID: '+id)
        used.add(id)
        if not url.startswith('https://images.scrydex.com/pokemon/') and not url.startswith('https://127.0.0.1/'):
            raise ValueError('Untrusted image URL: '+url)
        status,detail=check_fn(url)
        target=cards.get(id,[])
        slot=None
        if len(target)==1:
            slots=[s for s in target[0].findall('set') if (s.get('num') or '').lstrip('0')==r['CollectorNumber'].lstrip('0')]
            if len(slots)==1: slot=slots[0]
        if status=='OK_IMAGE' and slot is None: status='XML_MATCH_AMBIGUOUS'
        if status=='OK_IMAGE' and slot is not None:
            if slot.get('picurl'):
                status='ALREADY_HAS_IMAGE'
            else:
                slot.set('picurl',url)
                overrides.append({'TCGdexId':r['TCGdexId'],'ImageUrl':url})
        audit.append({**r,'Status':status,'HTTPDetail':detail})
        print(f'[{i}/{len(candidates)}] {r["TCGdexId"]} => {status}',flush=True)
        if delay and i!=len(candidates):time.sleep(delay)
    with (outdir/'scrydex-358-http-audit.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=F+['HTTPDetail']);w.writeheader();w.writerows(audit)
    with (outdir/'image-overrides-verified-only.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=['TCGdexId','ImageUrl']);w.writeheader();w.writerows(overrides)
    tree.write(outdir/'01.PokemonTCG.scrydex-verified.xml',encoding='utf-8',xml_declaration=True)
    ET.parse(outdir/'01.PokemonTCG.scrydex-verified.xml')
    ps=[s for c in root.findall('./cards/card') for s in c.findall('set')]
    print('RESULT',dict(collections.Counter(x['Status'] for x in audit)), 'URLs',sum(bool(s.get('picurl')) for s in ps),'/',len(ps))
    print('Output:',outdir)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidates',type=pathlib.Path,default=pathlib.Path('Pokemon_358_Scrydex_Link_Candidates.csv'))
    p.add_argument('--xml',type=pathlib.Path,default=pathlib.Path('01.PokemonTCG_Link_Candidates_Plus_2.xml'))
    p.add_argument('--out',type=pathlib.Path,default=pathlib.Path('scrydex-verified-results'))
    p.add_argument('--delay',type=float,default=.15)
    a=p.parse_args()
    if a.delay<0:raise SystemExit('--delay cannot be negative')
    with a.candidates.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    process(rows,a.xml,a.out,delay=a.delay)
if __name__=='__main__':main()

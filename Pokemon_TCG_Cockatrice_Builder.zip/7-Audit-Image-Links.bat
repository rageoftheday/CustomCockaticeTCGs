@echo off
cd /d "%~dp0"
echo Checking first 150 unique artwork URLs. This only writes a report; it never edits XML.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Audit-Pokemon-Image-Links.ps1" -MaxUrls 150 -OnlyUnique
echo.
pause

@echo off
setlocal
cd /d "%~dp0"
where powershell.exe >nul 2>&1
if errorlevel 1 (echo Windows PowerShell 5.1 or later is required.& pause & exit /b 1)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-Pokemon.ps1" -ArtLanguages English %*
set "result=%errorlevel%"
echo.
if not "%result%"=="0" echo UPDATE FAILED - see Logs folder. Original XML is preserved.
if "%result%"=="0" echo Finished. Restart Cockatrice and enable Pokemon sets if prompted.
pause
exit /b %result%

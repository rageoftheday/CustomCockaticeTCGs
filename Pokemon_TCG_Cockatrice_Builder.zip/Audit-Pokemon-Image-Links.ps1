﻿#requires -version 5.1
[CmdletBinding()]
param([string]$XmlPath='', [int]$MaxUrls=150, [int]$TimeoutSec=10, [switch]$OnlyUnique, [switch]$Recheck)
$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$logDir=Join-Path $base 'Logs'; [void](New-Item -ItemType Directory -Force -Path $logDir)
if(-not $XmlPath){$XmlPath=Join-Path (Join-Path $base 'Output') '01.PokemonTCG.xml'}
if(-not (Test-Path -LiteralPath $XmlPath)){throw "XML not found: $XmlPath"}
if($MaxUrls -le 0 -or $MaxUrls -gt 10000){throw 'MaxUrls must be 1..10000'}
[xml]$db=Get-Content -LiteralPath $XmlPath -Raw -Encoding UTF8
$cacheFile=Join-Path $logDir 'image-link-check-cache.json'
$cache=@{}
if((Test-Path $cacheFile) -and -not $Recheck){
 try{$old=Get-Content -LiteralPath $cacheFile -Raw -Encoding UTF8 | ConvertFrom-Json
   foreach($item in @($old)){if($item.Url){$cache[[string]$item.Url]=$item}}
 }catch{Write-Warning "Discarding unreadable URL check cache: $_"}
}
$seen=@{};$entries=New-Object System.Collections.Generic.List[object]
foreach($card in @($db.cockatrice_carddatabase.cards.card)){
 foreach($set in @($card.set)){
  $url=[string]$set.picurl
  if(-not $url -or $url -notmatch '^https://'){continue}
  if($OnlyUnique -and $seen.ContainsKey($url)){continue}
  $seen[$url]=$true
  [void]$entries.Add([pscustomobject]@{Card=[string]$card.name;Set=[string]$set.'#text';Number=[string]$set.num;Url=$url})
 }
}
# Prioritize the TCGdex image CDN, where some paths are known to return 404.
$entries=@($entries|Sort-Object @{Expression={if($_.Url -match 'assets[.]tcgdex[.]net'){0}else{1}}},Card,Number|Select-Object -First $MaxUrls)
$result=New-Object System.Collections.Generic.List[object]
$index=0
foreach($e in $entries){
 $index++
 $code='';$state='';$detail='';$cached=$false
 if($cache.ContainsKey($e.Url)){
  $prior=$cache[$e.Url]
  $code=[string]$prior.Status;$state=[string]$prior.Result;$detail=[string]$prior.Error;$cached=$true
 }else{
  try{
   $request=[Net.HttpWebRequest][Net.WebRequest]::Create($e.Url)
   $request.Method='HEAD';$request.Timeout=$TimeoutSec*1000;$request.ReadWriteTimeout=$TimeoutSec*1000
   $request.AllowAutoRedirect=$true;$request.UserAgent='PokemonCockatriceLinkAudit/2.3'
   $response=[Net.HttpWebResponse]$request.GetResponse()
   try{$code=[string][int]$response.StatusCode; $type=[string]$response.ContentType
     $state=if($type -match '^image/'){ 'OK-IMAGE' }else{'CHECK-CONTENT-TYPE'}
     $detail=$type
   }finally{$response.Close()}
  }catch [Net.WebException] {
   $err=$_.Exception;$response=$err.Response
   if($response){$code=[string][int]([Net.HttpWebResponse]$response).StatusCode;$response.Close()}
   $state=if($code -eq '404' -or $code -eq '410'){'MISSING'}elseif($code -eq '403' -or $code -eq '405'){'BLOCKED-OR-HEAD-UNSUPPORTED'}else{'RETRY-LATER'}
   $detail=[string]$err.Message
  }catch{$state='RETRY-LATER';$detail=[string]$_}
  $cache[$e.Url]=[pscustomobject]@{Url=$e.Url;Status=$code;Result=$state;Error=$detail;CheckedUtc=[DateTime]::UtcNow.ToString('o')}
 }
 [void]$result.Add([pscustomobject]@{Card=$e.Card;Set=$e.Set;Number=$e.Number;Status=$code;Result=$state;Cached=$cached;Url=$e.Url;Detail=$detail})
 if(($index%25)-eq 0 -or $index -eq $entries.Count){Write-Host ("AUDIT {0}/{1} | latest={2} {3}" -f $index,$entries.Count,$code,$state)}
}
$report=Join-Path $logDir 'image-link-audit.csv'
$result|Export-Csv -Path $report -NoTypeInformation -Encoding UTF8
# Cache all prior URL checks; no destructive changes to source XML.
@($cache.Values)|ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $cacheFile -Encoding UTF8
Write-Host "Report: $report"
Write-Host "Statuses count:"; $result|Group-Object Result|ForEach-Object {Write-Host ("  {0}: {1}" -f $_.Name,$_.Count)}
Write-Host 'No XML image URLs were modified.'

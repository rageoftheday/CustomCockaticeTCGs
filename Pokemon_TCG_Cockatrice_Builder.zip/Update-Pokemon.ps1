﻿#requires -version 5.1
[CmdletBinding()]
param(
  [string]$CustomSetsPath = '',
  [ValidateSet('English')][string]$ArtLanguages='English',
  [int]$MaxCards=0,
  [switch]$BuildOnly,
  [switch]$RefreshCache,
  [int]$FallbackMaxLookups=120,
  [int]$FallbackTimeoutSec=12,
  [int]$FallbackCircuitLimit=1,
  [switch]$SkipSecondaryArtwork,
  [switch]$SkipLegacyGitHub,
  [switch]$AllowSameNameVisualFallback,
  [int]$LegacySetMaxDownloads=30
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Base = Split-Path -Parent $MyInvocation.MyCommand.Path
$Cache = Join-Path $Base 'Cache'
$Output = Join-Path $Base 'Output'
$LogDir = Join-Path $Base 'Logs'
$Backups = Join-Path $Base 'Backups'
foreach($p in @($Cache,$Output,$LogDir,$Backups)){[void](New-Item -ItemType Directory -Path $p -Force)}
$LogFile = Join-Path $LogDir ((Get-Date -Format 'yyyyMMdd-HHmmss')+'.log')
function Log([string]$Message){$line=('[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'),$Message); Write-Host $line; Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8}
function ProgressLine([string]$Stage,[int]$Done,[int]$Total,[string]$Extra=''){
  $pct=0
  if($Total -gt 0){$pct=[int][Math]::Floor(($Done*100.0)/$Total)}
  $bars=[int][Math]::Floor($pct/5)
  $bar=('[{0}{1}]' -f ('#'*$bars),('-'*(20-$bars)))
  Log ('{0} {1} {2,3}% ({3:N0}/{4:N0}) {5}' -f $Stage,$bar,$pct,$Done,$Total,$Extra)
}
function JsonGet([string]$Url,[string]$CacheName,[int]$CacheHours=168){
  $file=Join-Path $Cache ($CacheName+'.json')
  if ((Test-Path -LiteralPath $file) -and -not $RefreshCache -and ((Get-Date)-(Get-Item -LiteralPath $file).LastWriteTime).TotalHours -lt $CacheHours){try{return (Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json)}catch{Remove-Item -LiteralPath $file -Force}}
  for($attempt=1;$attempt -le 4;$attempt++){
    try{
      $data=Invoke-RestMethod -Uri $Url -TimeoutSec 75 -Headers @{'User-Agent'='PokemonCockatriceXMLBuilder/1.3'}
      # An unavailable/empty language can legitimately return JSON null or an empty body.
      # PowerShell's Set-Content writes no file for null pipeline input.
      # Reject null BEFORE caching or attempting to move the temporary file.
      if ($null -eq $data) { throw "Empty/null API response (no cache file created)" }
      $json=ConvertTo-Json -InputObject $data -Depth 45 -Compress
      if ([string]::IsNullOrWhiteSpace($json) -or $json.Trim() -eq 'null') {
        throw "Empty/null JSON response (no cache file created)"
      }
      $tmp=$file+'.new'
      try {
        [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))
        if (-not (Test-Path -LiteralPath $tmp -PathType Leaf)) { throw "Temporary cache file was not written: $tmp" }
        Move-Item -LiteralPath $tmp -Destination $file -Force -ErrorAction Stop
      } finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
      }
      return $data
    }catch{
      if($attempt -eq 4){throw "API download failed: $Url : $_"}
      Start-Sleep -Seconds ($attempt*2)
    }
  }
}
# PowerShell 5.1 sometimes wraps cached JSON root arrays in one extra array.
# Normalize the API index shape to individual set/card objects before counting.
function Normalize-Index($InputValue) {
  # Earlier cache versions saved API index arrays as {value:[...],Count:N}.
  # Unwrap those records rather than treating the whole catalog as one item.
  $nested=Val $InputValue 'value'
  if($null -ne $nested){$InputValue=$nested}
  $result = New-Object 'System.Collections.Generic.List[object]'
  foreach($entry in @($InputValue)) {
    if($null -eq $entry) { continue }
    if($entry -is [System.Array] -or $entry -is [System.Collections.IList]) {
      foreach($inner in $entry) { if($null -ne $inner) { [void]$result.Add($inner) } }
    } else {
      [void]$result.Add($entry)
    }
  }
  return $result.ToArray()
}
function Get-EnglishIndexes {
  # Preserve existing per-card caches; only refresh malformed/stale index files.
  $setIndex='index-sets-en'; $cardIndex='index-cards-en'
  for($pass=1;$pass -le 2;$pass++) {
    $setRaw=JsonGet 'https://api.tcgdex.net/v2/en/sets' $setIndex 12
    $cardRaw=JsonGet 'https://api.tcgdex.net/v2/en/cards' $cardIndex 12
    $sets=@(Normalize-Index $setRaw)
    $cards=@(Normalize-Index $cardRaw)
    if($sets.Count -ge 100 -and $cards.Count -ge 1000 -and (Val $sets[0] 'id') -and (Val $cards[0] 'id')) {
      return @{ sets=$sets; cards=$cards }
    }
    Log "WARN: English cache/index abnormal (sets=$($sets.Count), cards=$($cards.Count)); refusing partial XML."
    if($pass -eq 1) {
      foreach($key in @($setIndex,$cardIndex)) {
        $bad=Join-Path $Cache ($key+'.json')
        if(Test-Path -LiteralPath $bad) {
          Move-Item -LiteralPath $bad -Destination ($bad+'.invalid-'+(Get-Date -Format 'yyyyMMddHHmmss')) -Force
        }
      }
      Log 'Refreshing ONLY English indexes; downloaded en-card-* detail files will be preserved.'
    }
  }
  throw "English indexes are still incomplete after refreshing. Previous XML preserved."
}
# TCGplayer product pages are NOT image URLs. Official API access requires existing
# credentials; no scraping, guessing CDN paths, or matching on name alone.
# Overrides accept DIRECT, permissioned HTTPS image URLs after operator verification.
$OverridesFile=Join-Path $Base 'image-overrides.csv'
$ArtworkOverrides=@{}
if(Test-Path -LiteralPath $OverridesFile){
  foreach($r in @(Import-Csv -LiteralPath $OverridesFile)){
    $rid=([string]$r.TCGdexId).Trim();$url=([string]$r.ImageUrl).Trim()
    if(-not $rid -or -not $url){continue}
    $uri=$null
    if([uri]::TryCreate($url,[uriKind]::Absolute,[ref]$uri) -and $uri.Scheme -eq 'https' -and $uri.AbsolutePath -match '(?i)[.](jpg|jpeg|png|webp)$'){ 
      $ArtworkOverrides[$rid]=$url
    }else{Log "WARN: invalid image override URL for $rid (must be a direct HTTPS .jpg/.png/.webp image, not a web page)."}
  }
}
$script:SecondaryLookups=0
$script:SecondaryHits=0
$script:SecondaryFailed=0
$script:SecondaryCacheHits=0
$script:SecondaryNegativeHits=0
$script:SecondaryTransientStreak=0
$script:SecondaryCircuitOpen=$false
$script:SecondaryCircuitLogged=$false
$script:LastSecondaryRequest=[datetime]::MinValue
$script:SourceQuarantineFile=Join-Path $Cache 'artwork-disabled-sources.json'
$script:DisabledArtworkSources=@{}
if(Test-Path -LiteralPath $script:SourceQuarantineFile){
  try {
    $persisted=Get-Content -LiteralPath $script:SourceQuarantineFile -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach($item in @($persisted.sources)) {
      if($null -ne $item -and $item.name){$script:DisabledArtworkSources[[string]$item.name]=$item}
    }
  }catch{Log "WARN: Cannot read disabled-artwork-sources file; no sources disabled from saved state: $_"}
}
function Disable-ArtworkSource([string]$Source,[string]$Reason){
  $stamp=[datetime]::UtcNow.ToString('o')
  $script:DisabledArtworkSources[$Source]=[pscustomobject]@{name=$Source;disabledAtUtc=$stamp;reason=$Reason}
  $records=@($script:DisabledArtworkSources.Values | Sort-Object name)
  $payload=ConvertTo-Json -InputObject @{version=1;sources=$records} -Depth 8
  $temp=$script:SourceQuarantineFile+'.new'
  try{
    [System.IO.File]::WriteAllText($temp,$payload,(New-Object System.Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temp -Destination $script:SourceQuarantineFile -Force
    Log "WARN: Artwork source $Source DISABLED and saved for future runs. Reason: $Reason. Existing cache and overrides remain active. Run 5-Reset-Disabled-Artwork-Sources.bat to re-enable."
  }catch{Log "WARN: Could not persist disabled artwork source: $_"}
}
function Is-SourceFailure($ErrorRecord){
  # A missing or mistyped individual card is NOT evidence the provider is down.
  # Quarantine only rate limits, server errors, timeouts and connectivity failures.
  $s=[string]$ErrorRecord
  $response=$ErrorRecord.Exception.Response
  if($null -ne $response){
    try{
      $code=[int]$response.StatusCode
      if($code -eq 429 -or $code -ge 500){return $true}
      if($code -ge 400 -and $code -lt 500){return $false}
    }catch{}
  }
  if($s -match '(?i)(\b429\b|\b5\d\d\b|timed?\s*out|timeout|connect|network|name resolution|dns|temporarily unavailable|proxy|remote host)'){return $true}
  return $false
}
if($script:DisabledArtworkSources.ContainsKey('pokemontcg.io')){
  $script:SecondaryCircuitOpen=$true
  Log 'Artwork source pokemontcg.io previously disabled after a provider error. Skipping live requests; cached successful images and manual overrides still available.'
}

# 2026: public historical card-data repo is a distinct non-live fallback.
# Only accept exact English set NAME + collector NUMBER + card NAME.
# Use index map from repository, never infer image paths or forge card IDs.
$script:LegacyRepo='PokemonTCG/pokemon-tcg-data'
$script:LegacySource='raw.githubusercontent.com'
$script:LegacySetMap=@{}
$script:LegacyCardMaps=@{}
$script:LegacyDownloads=0
$script:LegacyHits=0
$script:LegacyMisses=0
$script:LegacyErrors=0
$script:LegacyReport=New-Object 'System.Collections.Generic.List[object]'
function Legacy-CleanName([string]$Value) {
  if(-not $Value){return ''}
  return (($Value.ToLowerInvariant().Replace('&','and')) -replace '[^a-z0-9]','')
}
function Legacy-CleanNumber([string]$Value) {
  $v=([string]$Value).Trim().ToUpperInvariant()
  if($v -match '^0*[0-9]+$'){return ([long]$v).ToString()}
  return $v
}
function Legacy-CacheJson([string]$Url,[string]$CacheName,[int]$MaxAgeDays=30){
  $file=Join-Path $Cache $CacheName
  $notFound=$file+'.notfound'
  if(Test-Path -LiteralPath $notFound){
    if(((Get-Date)-(Get-Item -LiteralPath $notFound).LastWriteTime).TotalDays -lt $MaxAgeDays){return $null}
    Remove-Item -LiteralPath $notFound -Force -ErrorAction SilentlyContinue
  }
  if(Test-Path -LiteralPath $file){
    try{
      $content=Get-Content -LiteralPath $file -Raw -Encoding UTF8
      $parsed=$content|ConvertFrom-Json
      if($null -ne $parsed){return $parsed}
    }catch{Log "WARN: invalid legacy artwork cache $CacheName; ignoring cached data."}
  }
  if($SkipLegacyGitHub -or $script:DisabledArtworkSources.ContainsKey($script:LegacySource)){return $null}
  if($script:LegacyDownloads -ge $LegacySetMaxDownloads){return $null}
  $script:LegacyDownloads++
  try{
    # GitHub static files; bounded per-request time and persistent source quarantine.
    $response=Invoke-RestMethod -Uri $Url -TimeoutSec $FallbackTimeoutSec -Headers @{'User-Agent'='PokemonCockatriceArtworkRecovery/2.1'}
    if($null -eq $response){return $null}
    $json=ConvertTo-Json -InputObject $response -Depth 50 -Compress
    if([string]::IsNullOrWhiteSpace($json) -or $json -eq 'null'){return $null}
    [System.IO.File]::WriteAllText(($file+'.new'),$json,(New-Object System.Text.UTF8Encoding($false)))
    Move-Item -LiteralPath ($file+'.new') -Destination $file -Force
    return $response
  }catch{
    $script:LegacyErrors++
    $http=0
    try{$http=[int]$_.Exception.Response.StatusCode}catch{}
    if($http -eq 404){
      [IO.File]::WriteAllText($notFound,(Get-Date).ToString('o'))
      Log "INFO: legacy artwork catalog not published for $CacheName (404; retry after $MaxAgeDays days)."
    }elseif(Is-SourceFailure $_){
      Disable-ArtworkSource $script:LegacySource ([string]$_)
    }else{
      Log "WARN: legacy artwork lookup failed for $CacheName : $_"
    }
    return $null
  }
}
function Legacy-InitializeSetMap {
  if($SkipLegacyGitHub){return}
  $url='https://raw.githubusercontent.com/PokemonTCG/pokemon-tcg-data/master/sets/en.json'
  $data=Legacy-CacheJson $url 'art-legacy-index-en.json'
  if($null -eq $data){return}
  $sets=@(Normalize-Index $data)
  foreach($s in $sets){
    $name=Txt (Val $s 'name');$id=Txt (Val $s 'id')
    $key=Legacy-CleanName $name
    if(-not $key -or -not $id){continue}
    if($script:LegacySetMap.ContainsKey($key)){
      $script:LegacySetMap[$key]='' # ambiguous names: reject
    }else{$script:LegacySetMap[$key]=$id}
  }
  Log "Legacy image source index: $($script:LegacySetMap.Count) set names cached; max new catalog downloads=$LegacySetMaxDownloads"
}
function Legacy-GetSetCards([string]$SetName){
  $key=Legacy-CleanName $SetName
  if(-not $script:LegacySetMap.ContainsKey($key)){return $null}
  $legacySetId=$script:LegacySetMap[$key]
  if(-not $legacySetId){return $null}
  if($script:LegacyCardMaps.ContainsKey($legacySetId)){return $script:LegacyCardMaps[$legacySetId]}
  $url='https://raw.githubusercontent.com/PokemonTCG/pokemon-tcg-data/master/cards/en/'+[uri]::EscapeDataString($legacySetId)+'.json'
  $data=Legacy-CacheJson $url ('art-legacy-cards-'+$legacySetId+'.json')
  if($null -eq $data){return $null}
  $map=@{}
  foreach($card in @(Normalize-Index $data)){
    $name=Txt (Val $card 'name');$number=Txt (Val $card 'number')
    $image=Txt (Val (Val $card 'images') 'large')
    if(-not $image){$image=Txt (Val (Val $card 'images') 'small')}
    if(-not $name -or -not $number -or $image -notmatch '^https://images[.]pokemontcg[.]io/[a-z0-9]+/[^/]+[.]png$'){continue}
    $cardKey=(Legacy-CleanName $name)+'|'+(Legacy-CleanNumber $number)
    if($map.ContainsKey($cardKey)){$map[$cardKey]=''} # ambiguity must not auto-match
    else{$map[$cardKey]=$image}
  }
  $script:LegacyCardMaps[$legacySetId]=$map
  return $map
}
function Lookup-LegacyGithubArtwork([string]$CardId,[string]$Name,[string]$SetName,[string]$Number){
  if($SkipLegacyGitHub){return $null}
  $map=Legacy-GetSetCards $SetName
  if($null -eq $map){return $null}
  $key=(Legacy-CleanName $Name)+'|'+(Legacy-CleanNumber $Number)
  if(-not $map.ContainsKey($key) -or -not $map[$key]){$script:LegacyMisses++;return $null}
  $script:LegacyHits++
  [void]$script:LegacyReport.Add([pscustomobject]@{CardId=$CardId;CardName=$Name;Set=$SetName;Number=$Number;ImageUrl=$map[$key];Source='PokemonTCG/pokemon-tcg-data';Match='Exact English set name, card name and collector number'})
  return @{url=$map[$key];source='PokemonTCG/pokemon-tcg-data'}
}

function Normalize-ArtName([string]$Name){
  if(-not $Name){return ''}
  $v=$Name.ToLowerInvariant().Replace('&','and')
  return ($v -replace '[^a-z0-9]','')
}
function Same-ArtName([string]$English,[string]$Candidate){
  $a=Normalize-ArtName $English;$b=Normalize-ArtName $Candidate
  if($a -eq $b){return $true}
  # Some sources call Basic Grass Energy simply Grass Energy.
  if($a -match '^basic(grass|fire|water|lightning|psychic|fighting|darkness|metal|fairy)energy$'){
    return ($a -replace '^basic','') -eq $b
  }
  return $false
}
function Lookup-SecondaryArtwork([string]$CardId,[string]$Name,[string]$SetName,[string]$LocalId){
  # File-based override has priority only for exact TCGdex IDs.
  if($ArtworkOverrides.ContainsKey($CardId)){
    return @{url=$ArtworkOverrides[$CardId];source='verified-override'}
  }
  if($SkipSecondaryArtwork){return $null}
  if(-not $LocalId -or -not $SetName -or -not $Name){return $null}
  $safeId=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($CardId)).TrimEnd('=').Replace('/','_').Replace('+','-')
  $cacheFile=Join-Path $Cache ('art-pokemontcg-'+$safeId+'.json')
  $record=$null
  if(Test-Path -LiteralPath $cacheFile){
    try{
      $record=Get-Content -LiteralPath $cacheFile -Raw -Encoding UTF8 | ConvertFrom-Json
      if([string]$record.cardId -ne $CardId){$record=$null}
      # Retry unmatched results after 14 days, without changing existing positive mappings.
      if($null -ne $record -and -not $record.url -and ((Get-Date)-(Get-Item -LiteralPath $cacheFile).LastWriteTime).TotalDays -gt 14){$record=$null}
      if($null -ne $record){
        if($record.url){$script:SecondaryCacheHits++}else{$script:SecondaryNegativeHits++}
      }
    }catch{$record=$null}
  }
  if($null -eq $record){
    if($script:SecondaryCircuitOpen){return $null} # Cached matches still work after breaker opens.
    if($FallbackMaxLookups -gt 0 -and $script:SecondaryLookups -ge $FallbackMaxLookups){return $null}
    $script:SecondaryLookups++
    $limitLabel=if($FallbackMaxLookups -gt 0){[string]$FallbackMaxLookups}else{'unlimited'}
    Log ("  Artwork API request $($script:SecondaryLookups) / $limitLabel : $CardId (timeout ${FallbackTimeoutSec}s)")
    $elapsed=((Get-Date)-$script:LastSecondaryRequest).TotalMilliseconds
    if($elapsed -lt 2200){Start-Sleep -Milliseconds ([int](2200-$elapsed))}
    $script:LastSecondaryRequest=Get-Date
    $q='number:"'+($LocalId.Replace('"',''))+'" name:"'+($Name.Replace('"',''))+'"'
    $url='https://api.pokemontcg.io/v2/cards?q='+[uri]::EscapeDataString($q)+'&pageSize=100'
    try {
      $response=Invoke-RestMethod -Uri $url -TimeoutSec $FallbackTimeoutSec -Headers @{'User-Agent'='PokemonCockatriceXMLBuilder/1.6'}
      $match=New-Object System.Collections.Generic.List[object]
      foreach($item in @($response.data)){
        if($null -eq $item){continue}
        $candidateNumber=Txt (Val $item 'number')
        $candidateName=Txt (Val $item 'name')
        $candidateSet=Txt (Val (Val $item 'set') 'name')
        $candidateImage=Txt (Val (Val $item 'images') 'large')
        if($candidateNumber -eq $LocalId -and (Same-ArtName $Name $candidateName) -and
           (Normalize-ArtName $SetName) -eq (Normalize-ArtName $candidateSet) -and
           $candidateImage -match '^https://images[.]pokemontcg[.]io/'){
          [void]$match.Add($item)
        }
      }
      $art='';$ref=''
      if($match.Count -eq 1){$art=Txt (Val (Val $match[0] 'images') 'large');$ref=Txt (Val $match[0] 'id')}
      $script:SecondaryTransientStreak=0
      $record=[pscustomobject]@{cardId=$CardId;url=$art;source='pokemontcg.io';matchedId=$ref;candidateCount=$match.Count}
      $json=ConvertTo-Json -InputObject $record -Depth 5 -Compress
      [System.IO.File]::WriteAllText(($cacheFile+'.new'),$json,(New-Object System.Text.UTF8Encoding($false)))
      Move-Item -LiteralPath ($cacheFile+'.new') -Destination $cacheFile -Force
    }catch {
      $script:SecondaryFailed++
      $script:SecondaryTransientStreak++
      Log "WARN: alternate artwork API failed for $CardId : $_ (consecutive failures=$script:SecondaryTransientStreak)"
      if((Is-SourceFailure $_) -and -not $script:SecondaryCircuitOpen){
        $script:SecondaryCircuitOpen=$true
        Disable-ArtworkSource 'pokemontcg.io' ([string]$_)
      }elseif($FallbackCircuitLimit -gt 0 -and $script:SecondaryTransientStreak -ge $FallbackCircuitLimit -and -not $script:SecondaryCircuitOpen){
        $script:SecondaryCircuitOpen=$true
        Disable-ArtworkSource 'pokemontcg.io' ("$FallbackCircuitLimit consecutive API errors; latest: $_")
      }
      return $null # Don't cache rate limits, network failures, or server errors.
    }
  }
  if($record.url -and $record.url -match '^https://images[.]pokemontcg[.]io/'){
    $script:SecondaryHits++
    return @{url=[string]$record.url;source='pokemontcg.io'}
  }
  return $null
}

function PathFor([string]$part){return [uri]::EscapeDataString($part)}
function Get-Candidates {
  $found=New-Object System.Collections.Generic.List[string]
  $local=@(
    (Join-Path $env:LOCALAPPDATA 'Cockatrice\Cockatrice\customsets'),
    (Join-Path $env:APPDATA 'Cockatrice\Cockatrice\customsets'),
    (Join-Path $env:LOCALAPPDATA 'Cockatrice\customsets'),
    (Join-Path $env:APPDATA 'Cockatrice\customsets'),
    (Join-Path $env:USERPROFILE 'AppData\Local\Cockatrice\Cockatrice\customsets'),
    (Join-Path $Base 'customsets'),(Join-Path $Base 'data\customsets'),
    (Join-Path (Split-Path $Base -Parent) 'data\customsets')
  )
  $ini=Join-Path $Base 'pokemon-location.txt'
  if(Test-Path $ini){$saved=(Get-Content $ini -Raw).Trim(); if($saved){$local=@($saved)+$local}}
  foreach($root in @($Base,(Split-Path $Base -Parent),$env:ProgramFiles,${env:ProgramFiles(x86)})){
    if($root -and (Test-Path $root)){
      foreach($rel in @('Cockatrice\data\customsets','Cockatrice\customsets','data\customsets')){$local+=Join-Path $root $rel}
    }
  }
  foreach($path in $local){if($path -and (Test-Path -LiteralPath $path -PathType Container)){
    try{$full=[IO.Path]::GetFullPath($path);if(-not $found.Contains($full)){$found.Add($full)}}catch{}
  }}
  return $found.ToArray()
}
function Select-Target {
  if($CustomSetsPath){return [IO.Path]::GetFullPath($CustomSetsPath)}
  $candidates=@(Get-Candidates)
  if($candidates.Count -gt 0){
    Log 'Detected possible customsets folders:'
    for($i=0;$i -lt $candidates.Count;$i++){Write-Host ('  [{0}] {1}' -f ($i+1),$candidates[$i])}
  }
  Write-Host '  [M] Manually choose a folder    [S] Save to Output only'
  $choice=Read-Host 'Select the actual Cockatrice customsets directory (Enter = 1 if found, otherwise M)'
  if($choice -eq 'S'){return ''}
  if($choice -eq 'M' -or $candidates.Count -eq 0){
    Add-Type -AssemblyName System.Windows.Forms
    $dlg=New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description='Choose Cockatrice customsets (Card Database > Open custom sets folder)'
    if($dlg.ShowDialog() -ne [Windows.Forms.DialogResult]::OK){throw 'No folder chosen. Nothing was installed.'}
    $selected=$dlg.SelectedPath
    if ((Split-Path $selected -Leaf) -ne 'customsets') {
      $confirmed=Read-Host "Selected folder is not named customsets. Install here anyway? Type YES"
      if($confirmed -cne 'YES'){throw 'Cancelled. Nothing was installed.'}
    }
    return $selected
  }
  if([string]::IsNullOrWhiteSpace($choice)){$choice='1'}
  $index=0
  if(-not [int]::TryParse($choice,[ref]$index) -or $index -lt 1 -or $index -gt $candidates.Count){throw 'Invalid selection.'}
  return $candidates[$index-1]
}
function Val($o,[string]$n){if($null -eq $o){return $null};$p=$o.PSObject.Properties[$n];if($p){return $p.Value};return $null}
function Txt($o){if($null -eq $o){return ''};return [string]$o}
function JoinItems($o){if($null -eq $o){return ''};return (@($o) | ForEach-Object {Txt $_}) -join ', '}
function MechanicalKey($c){
  # Exclude collector, rarity, art, illustrator and set. Include mechanics and English game wording.
  $name=Txt (Val $c 'name')
  $parts=New-Object System.Collections.Generic.List[string]
  $parts.Add($name)
  foreach($field in @('category','hp','types','stage','evolveFrom','suffix','trainerType','energyType','effect','retreat','weaknesses','resistances','regulationMark','description')){
    $v=Val $c $field
    if($null -ne $v){$parts.Add(($field+':'+($v|ConvertTo-Json -Depth 18 -Compress)))}
  }
  foreach($field in @('attacks','abilities')){
    $v=Val $c $field
    if($null -ne $v){$parts.Add(($field+':'+($v|ConvertTo-Json -Depth 18 -Compress)))}
  }
  return ($parts -join '|')
}
function DetailText($c){
  $lines=New-Object System.Collections.Generic.List[string]
  $category=Txt (Val $c 'category');$name=Txt (Val $c 'name')
  $lines.Add('Pokemon TCG | '+$category)
  foreach($field in @('hp','stage','evolveFrom','suffix','trainerType','energyType')){
    $v=Val $c $field
    if($v){$lines.Add(('{0}: {1}' -f $field,$v))}
  }
  $types=JoinItems (Val $c 'types');if($types){$lines.Add('Types: '+$types)}
  foreach($a in @(Val $c 'abilities')){
    if($null -eq $a){continue};$lines.Add('ABILITY: '+(Txt (Val $a 'name')))
    $type=Txt (Val $a 'type');if($type){$lines.Add('Type: '+$type)}
    $effect=Txt (Val $a 'effect');if($effect){$lines.Add($effect)}
  }
  foreach($a in @(Val $c 'attacks')){
    if($null -eq $a){continue};$lines.Add('ATTACK: '+(Txt (Val $a 'name')))
    $cost=JoinItems (Val $a 'cost');if($cost){$lines.Add('Cost: '+$cost)}
    $damage=Txt (Val $a 'damage');if($damage){$lines.Add('Damage: '+$damage)}
    $effect=Txt (Val $a 'effect');if($effect){$lines.Add($effect)}
  }
  $effect=Txt (Val $c 'effect');if($effect){$lines.Add('Effect: '+$effect)}
  foreach($field in @('weaknesses','resistances')){
    foreach($v in @(Val $c $field)){
      if($null -eq $v){continue};$lines.Add(('{0}: {1} {2}' -f $field,(Txt (Val $v 'type')),(Txt (Val $v 'value'))))
    }
  }
  $retreat=Val $c 'retreat';if($null -ne $retreat){$lines.Add('Retreat Cost: '+$retreat)}
  return ($lines -join "`n")
}
function SetCode([string]$language,[string]$setid){
  # Stable set IDs. English-only edition.
  $raw=$language.ToUpperInvariant()+'|'+$setid
  $sha=[Security.Cryptography.SHA1]::Create()
  try{$bytes=[Text.Encoding]::UTF8.GetBytes($raw);$hash=[BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','').Substring(0,9)}finally{$sha.Dispose()}
  return 'PK'+$language.ToUpperInvariant().Replace('-','')+$hash
}
function WriteNode($writer,[string]$tag,[string]$value){$writer.WriteElementString($tag,$value)}
try{
  Log 'Pokemon Cockatrice XML updater v2.2 | English only | strict images + optional same-name visual placeholders'
  $languages=@('en')
  $setMap=@{};$imageMap=@{};$englishCards=@{}
  foreach($lang in $languages){
    Log "Loading $lang set/card indexes ..."
    try{
      $indexes=Get-EnglishIndexes
      $sets=@($indexes.sets)
      $cards=@($indexes.cards)
    }catch{
      if($lang -eq 'en'){throw}
      Log "WARN: $lang index failed; skipping language: $_";continue
    }
    if($sets.Count -eq 0 -or $cards.Count -eq 0){
      if($lang -eq 'en'){throw 'English catalog is empty. Existing XML untouched.'}
      Log "SKIP: $lang has no published sets/cards; continuing with other languages."
      continue
    }
    foreach($set in $sets){
      $sid=Txt (Val $set 'id');if(-not $sid){continue}
      $code=SetCode $lang $sid
      $setMap[$code]=@{id=$sid;lang=$lang;name=(Txt (Val $set 'name'));date=(Txt (Val $set 'releaseDate'))}
    }
    foreach($card in $cards){
      $id=Txt (Val $card 'id');$image=Txt (Val $card 'image')
      if(-not $id){continue}
      $local=Txt (Val $card 'localId')
      if($image){$imageMap[$lang+'|'+$id]=@{image=$image.TrimEnd('/')+'/high.png';local=$local}}
      if($lang -eq 'en'){$englishCards[$id]=$card}
    }
    Log "$lang sets=$($sets.Count) indexCards=$($cards.Count) imageLinks=$((@($cards|Where-Object {$_.image})).Count)"
  }
  if($englishCards.Count -eq 0){throw 'English index empty; refusing to create an empty database.'}
  $ids=@($englishCards.Keys | Sort-Object)
  if($MaxCards -gt 0){$ids=@($ids|Select-Object -First $MaxCards);Log "TEST LIMIT: processing $($ids.Count) English cards"}
  $entries=@{};$loaded=0;$processed=0;$failed=New-Object System.Collections.Generic.List[string]
  Log ("Stage 1/3: loading $($ids.Count) English card details (cache reuse enabled).")
  ProgressLine 'CARDS' 0 $ids.Count 'building mechanical entries'
  foreach($id in $ids){
    $processed++
    try{$c=JsonGet ("https://api.tcgdex.net/v2/en/cards/"+(PathFor $id)) ('en-card-'+([Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($id)).TrimEnd('=').Replace('/','_').Replace('+','-')))}
    catch{$failed.Add($id);Log "WARN: card $id failed: $_";continue}
    if(-not (Val $c 'name')){$failed.Add($id);continue}
    $key=MechanicalKey $c
    if(-not $entries.ContainsKey($key)){
      $entries[$key]=@{name=(Txt (Val $c 'name'));text=(DetailText $c);category=(Txt (Val $c 'category'));first=$id;prints=(New-Object System.Collections.ArrayList)}
    }
    $group=$entries[$key]
    $sid=Txt (Val (Val $c 'set') 'id')
    if(-not $sid){$sid=($id -split '-')[0]}
    $local=Txt (Val $c 'localId')
    $rarity=Txt (Val $c 'rarity')
    $sourceSetName=Txt (Val (Val $c 'set') 'name')
    # The English set/card index sometimes omits an artwork URL that IS present
    # in the per-card detail. Prefer the detail URL for the exact printing.
    $detailImage=Txt (Val $c 'image')
    if($detailImage) {
      $imageMap['en|'+$id]=@{image=$detailImage.TrimEnd('/')+'/high.png';local=$local}
    }
    foreach($lang in $languages){
      $mapkey=$lang+'|'+$id
      if(-not $imageMap.ContainsKey($mapkey)){continue}
      $code=SetCode $lang $sid
      if(-not $setMap.ContainsKey($code)){continue}
      $pic=$imageMap[$mapkey]
      $number=$pic.local;if(-not $number){$number=$local}
      [void]$group.prints.Add(@{code=$code;num=$number;url=$pic.image;rarity=$rarity;id=$lang+'|'+$id;name=(Txt (Val $c 'name'));setName=$sourceSetName})
    }
    # Preserve English source cards even when TCGdex does not provide an image.
    if(-not $imageMap.ContainsKey('en|'+$id)){
      $code=SetCode 'en' $sid
      if($setMap.ContainsKey($code)){[void]$group.prints.Add(@{code=$code;num=$local;url='';rarity=$rarity;id='en|'+$id;name=(Txt (Val $c 'name'));setName=$sourceSetName})}
    }
    $loaded++
    if(($processed % 100) -eq 0 -or $processed -eq $ids.Count){
      ProgressLine 'CARDS' $processed $ids.Count ("loaded=$loaded groups=$($entries.Count) errors=$($failed.Count)")
    }
  }
  if($failed.Count -gt 0){
    $failFile=Join-Path $LogDir 'failed-card-ids.txt';$failed | Set-Content -LiteralPath $failFile -Encoding UTF8
    throw "$($failed.Count) card details failed. Cache retains successes; retry the updater. Existing XML untouched. See $failFile"
  }
  if($entries.Count -eq 0){throw 'No card entries produced.'}
  # Resolve missing printings through verified exact-name + exact-number + exact-set
  # cross-references. Existing artwork URLs are never changed.
  $missingPrints=New-Object 'System.Collections.Generic.List[object]'
  foreach($e in $entries.Values){
    foreach($p in $e.prints){if([string]::IsNullOrWhiteSpace($p.url)){[void]$missingPrints.Add($p)}}
  }
  $missingBefore=$missingPrints.Count;$recovered=0;$artProcessed=0
  Legacy-InitializeSetMap
  # Prioritize sets with the most missing printings; download a catalog once per set.
  $missingPrints=@($missingPrints | Group-Object -Property { $_.setName } | Sort-Object Count -Descending | ForEach-Object { $_.Group })
  Log "Stage 2/3: checking $missingBefore printings missing artwork; exact-match cache and overrides first."
  ProgressLine 'ARTWORK' 0 $missingBefore 'starting'
  foreach($p in $missingPrints){
    $artProcessed++
    $id=([string]$p.id -replace '^en[|]','')
    $result=$null
    if($ArtworkOverrides.ContainsKey($id)){$result=@{url=$ArtworkOverrides[$id];source='verified-override'}}
    if(-not $result){$result=Lookup-LegacyGithubArtwork $id ([string]$p.name) ([string]$p.setName) ([string]$p.num)}
    if(-not $result){$result=Lookup-SecondaryArtwork $id ([string]$p.name) ([string]$p.setName) ([string]$p.num)}
    if($result -and $result.url){$p.url=[string]$result.url;$recovered++}
    if(($artProcessed % 25) -eq 0 -or $artProcessed -eq $missingBefore){
      ProgressLine 'ARTWORK' $artProcessed $missingBefore ("recovered=$recovered api=$script:SecondaryLookups errors=$script:SecondaryFailed cache+=$script:SecondaryCacheHits cached-misses=$script:SecondaryNegativeHits breaker=$script:SecondaryCircuitOpen")
    }
  }
  $legacyReportFile=Join-Path $LogDir 'legacy-github-artwork-recovered.csv'
  if($script:LegacyReport.Count -gt 0){$script:LegacyReport | Export-Csv -LiteralPath $legacyReportFile -NoTypeInformation -Encoding UTF8}
  else{[IO.File]::WriteAllText($legacyReportFile,'CardId,CardName,Set,Number,ImageUrl,Source,Match'+[Environment]::NewLine)}
  Log "Legacy archive: recovered=$($script:LegacyHits); new downloads=$($script:LegacyDownloads); errors=$($script:LegacyErrors); report=$legacyReportFile"
  # As a final offline fallback, borrow existing artwork ONLY inside an
  # identical MechanicalKey group. Never match on card name alone.
  $borrowed=0
  $substituteRows=New-Object 'System.Collections.Generic.List[object]'
  foreach($e in $entries.Values){
    $donor=$null
    foreach($candidate in $e.prints){
      if(-not [string]::IsNullOrWhiteSpace([string]$candidate.url)){$donor=$candidate;break}
    }
    if($null -eq $donor){continue}
    foreach($p in $e.prints){
      if(-not [string]::IsNullOrWhiteSpace([string]$p.url)){continue}
      $p.url=[string]$donor.url
      $borrowed++
      [void]$substituteRows.Add([pscustomobject][ordered]@{
        MissingCardId=([string]$p.id -replace '^en[|]','')
        CardName=[string]$e.name
        MissingSet=[string]$p.setName
        MissingNumber=[string]$p.num
        ArtSourceId=([string]$donor.id -replace '^en[|]','')
        ArtSourceSet=[string]$donor.setName
        ArtSourceNumber=[string]$donor.num
        ImageUrl=[string]$donor.url
        MatchRule='Same complete English mechanical record'
      })
    }
  }
  # A few cards have identical displayed game text despite differences in
  # non-game metadata (e.g. description/regulation marker) in the TCGdex API.
  # Apply this SECOND exact-visible-mechanics pass after the stricter key pass.
  # Do not use same-name-only matching: that can give a different Pokemon card.
  Log 'Artwork pass 2: comparing complete displayed English rules + name + category.'
  $visibleDonors=@{}
  foreach($e in $entries.Values){
    $visibleKey=([string]$e.name).ToLowerInvariant()+[char]31+([string]$e.category).ToLowerInvariant()+[char]31+([string]$e.text)
    if(-not $visibleDonors.ContainsKey($visibleKey)){
      foreach($candidate in $e.prints){
        if(-not [string]::IsNullOrWhiteSpace([string]$candidate.url)){
          $visibleDonors[$visibleKey]=$candidate
          break
        }
      }
    }
  }
  $visibleBorrowed=0
  foreach($e in $entries.Values){
    $visibleKey=([string]$e.name).ToLowerInvariant()+[char]31+([string]$e.category).ToLowerInvariant()+[char]31+([string]$e.text)
    if(-not $visibleDonors.ContainsKey($visibleKey)){continue}
    $donor=$visibleDonors[$visibleKey]
    foreach($p in $e.prints){
      if(-not [string]::IsNullOrWhiteSpace([string]$p.url)){continue}
      if([string]$p.id -eq [string]$donor.id){continue}
      $p.url=[string]$donor.url
      $visibleBorrowed++
      [void]$substituteRows.Add([pscustomobject][ordered]@{
        MissingCardId=([string]$p.id -replace '^en[|]','')
        CardName=[string]$e.name
        MissingSet=[string]$p.setName
        MissingNumber=[string]$p.num
        ArtSourceId=([string]$donor.id -replace '^en[|]','')
        ArtSourceSet=[string]$donor.setName
        ArtSourceNumber=[string]$donor.num
        ImageUrl=[string]$donor.url
        MatchRule='Same English name, category and complete displayed rules'
      })
    }
  }
  $borrowed+=$visibleBorrowed
  Log "Additional exact-rules artwork substitutions: $visibleBorrowed"
  $subReport=Join-Path $LogDir 'borrowed-artwork-report.csv'
  if($borrowed -gt 0){
    $substituteRows | Sort-Object CardName,MissingSet,MissingNumber | Export-Csv -LiteralPath $subReport -NoTypeInformation -Encoding UTF8
  }else{
    [System.IO.File]::WriteAllText($subReport,'MissingCardId,CardName,MissingSet,MissingNumber,ArtSourceId,ArtSourceSet,ArtSourceNumber,ImageUrl,MatchRule'+[Environment]::NewLine)
  }
  Log "Offline mechanically-identical artwork reuse: $borrowed printings; report=$subReport"
  Log "Artwork fallback: missing-before=$missingBefore API-recovered=$recovered mechanically-borrowed=$borrowed API-lookups=$script:SecondaryLookups API-errors=$script:SecondaryFailed cached-image-hits=$script:SecondaryCacheHits circuit-open=$script:SecondaryCircuitOpen"
  if($missingBefore -gt 0 -and $script:SecondaryLookups -ge $FallbackMaxLookups -and $FallbackMaxLookups -gt 0){
    Log "Artwork lookup budget reached ($FallbackMaxLookups). Re-run to continue; successful and negative lookups are cached. Use -FallbackMaxLookups 0 for unlimited."
  }
  # OPTIONAL visual-only fallback. This is NOT an exact printing or gameplay match.
  # Never enable by default; users must choose 6-Build-With-Visual-Placeholders.bat.
  $nameSubRows=New-Object 'System.Collections.Generic.List[object]'
  if($AllowSameNameVisualFallback){
    Log 'VISUAL PLACEHOLDER MODE: same-name art may show different attacks/HP; the XML rules remain authoritative.'
    $sameNameDonors=@{}
    foreach($e in @($entries.Values | Sort-Object name,first)){
      $k=([string]$e.name).ToLowerInvariant()+[char]31+([string]$e.category).ToLowerInvariant()
      foreach($candidate in @($e.prints | Sort-Object id,code,num)){
        if([string]::IsNullOrWhiteSpace([string]$candidate.url)){continue}
        if(-not $sameNameDonors.ContainsKey($k)){$sameNameDonors[$k]=New-Object 'System.Collections.Generic.List[object]'}
        [void]$sameNameDonors[$k].Add([pscustomobject]@{p=$candidate;rules=[string]$e.text})
      }
    }
    foreach($e in @($entries.Values | Sort-Object name,first)){
      $k=([string]$e.name).ToLowerInvariant()+[char]31+([string]$e.category).ToLowerInvariant()
      if(-not $sameNameDonors.ContainsKey($k)){continue}
      foreach($p in $e.prints){
        if(-not [string]::IsNullOrWhiteSpace([string]$p.url)){continue}
        # Prefer matching HP, stage and type (if displayed), then text similarity;
        # do not claim any matching mechanics when selecting a substitute.
        $best=$null;$score=-999
        foreach($d in $sameNameDonors[$k]){
          $s=0
          foreach($pattern in @('(?m)^hp: [^\n]+','(?m)^stage: [^\n]+','(?m)^Types: [^\n]+')){
            $a=[regex]::Match([string]$e.text,$pattern);$b=[regex]::Match([string]$d.rules,$pattern)
            if($a.Success -and $b.Success -and $a.Value -eq $b.Value){$s+=10}
          }
          if($s -gt $score){$score=$s;$best=$d.p}
        }
        if($null -eq $best){continue}
        $p.url=[string]$best.url
        [void]$nameSubRows.Add([pscustomobject][ordered]@{
          MissingCardId=([string]$p.id -replace '^en[|]','');CardName=[string]$e.name
          MissingSet=[string]$p.setName;MissingNumber=[string]$p.num
          ArtSourceId=([string]$best.id -replace '^en[|]','');ArtSourceSet=[string]$best.setName
          ArtSourceNumber=[string]$best.num;ImageUrl=[string]$best.url
          Warning='VISUAL PLACEHOLDER ONLY; attacks, HP, or other printed details may differ'
        })
      }
    }
    Log "Same-name visual placeholders: $($nameSubRows.Count). These are NOT exact art matches."
  }
  $placeholderReport=Join-Path $LogDir 'same-name-visual-placeholders.csv'
  if($nameSubRows.Count -gt 0){$nameSubRows | Export-Csv -LiteralPath $placeholderReport -NoTypeInformation -Encoding UTF8}
  else{[IO.File]::WriteAllText($placeholderReport,'MissingCardId,CardName,MissingSet,MissingNumber,ArtSourceId,ArtSourceSet,ArtSourceNumber,ImageUrl,Warning'+[Environment]::NewLine)}
  # Report exact card IDs still lacking artwork. Never make up an image URL or
  # borrow an incorrect printing just because the card has a matching name.
  $missingIds=New-Object System.Collections.Generic.List[string]
  foreach($e in $entries.Values){
    foreach($p in $e.prints){
      if([string]::IsNullOrWhiteSpace($p.url)){$missingIds.Add(($p.id -replace '^en[|]',''))}
    }
  }
  # PkmnCards has no public data API. Don't crawl its pages or hotlink unreviewed
  # images: create a small offline REVIEW QUEUE containing links that the operator
  # can open in a normal browser, then add permissioned exact-image URLs to
  # image-overrides.csv for reuse on all future builds.
  $reviewRows = New-Object 'System.Collections.Generic.List[object]'
  foreach($e in $entries.Values){
    foreach($p in $e.prints){
      if(-not [string]::IsNullOrWhiteSpace($p.url)){continue}
      $cid=([string]$p.id -replace '^en[|]','')
      $setName=[string]$p.setName
      $num=[string]$p.num
      $name=[string]$p.name
      # Search links are deliberately *links*, not automated site requests.
      $searchWords=($name+' '+$setName+' #'+$num).Trim()
      $siteUrl='https://pkmncards.com/?s='+[uri]::EscapeDataString($searchWords)
      $webUrl='https://www.google.com/search?q='+[uri]::EscapeDataString('site:pkmncards.com/card/ "'+$name+'" "'+$num+'"')
      $limitlessSearch='https://www.google.com/search?q='+[uri]::EscapeDataString('site:limitlesstcg.com/cards/ "'+$name+'" "'+$setName+'" "'+$num+'"')
      $bulbaSearch='https://www.google.com/search?q='+[uri]::EscapeDataString('site:bulbapedia.bulbagarden.net/wiki/ "'+$name+'" "'+$setName+'" "'+$num+'"')
      $officialSearch='https://www.pokemon.com/us/pokemon-tcg/pokemon-cards/'
      $tcgdexCard='https://www.tcgdex.net/card/'+[uri]::EscapeDataString($cid)
      [void]$reviewRows.Add([pscustomobject][ordered]@{
        TCGdexId=$cid; CardName=$name; EnglishSet=$setName; CollectorNumber=$num;
        PkmnCardsSearch=$siteUrl; WebSearch=$webUrl; LimitlessSearch=$limitlessSearch; BulbapediaSearch=$bulbaSearch; OfficialSearch=$officialSearch; TCGdexCard=$tcgdexCard; ImageUrl=''
      })
    }
  }
  $reviewFile=Join-Path $LogDir 'missing-artwork-review.csv'
  $reviewHtml=Join-Path $LogDir 'missing-artwork-review.html'
  $orderedReview=@($reviewRows | Sort-Object EnglishSet,CollectorNumber,CardName)
  $orderedReview | Export-Csv -LiteralPath $reviewFile -NoTypeInformation -Encoding UTF8
  # Generate a local browser review page without making any network requests.
  $htmlRows=New-Object 'System.Collections.Generic.List[string]'
  foreach($r in $orderedReview){
    $htmlId=[System.Net.WebUtility]::HtmlEncode($r.TCGdexId)
    $htmlName=[System.Net.WebUtility]::HtmlEncode($r.CardName)
    $htmlSet=[System.Net.WebUtility]::HtmlEncode($r.EnglishSet)
    $htmlNum=[System.Net.WebUtility]::HtmlEncode($r.CollectorNumber)
    $htmlSite=[System.Net.WebUtility]::HtmlEncode($r.PkmnCardsSearch)
    $htmlWeb=[System.Net.WebUtility]::HtmlEncode($r.WebSearch)
    $htmlLimitless=[System.Net.WebUtility]::HtmlEncode($r.LimitlessSearch)
    $htmlBulba=[System.Net.WebUtility]::HtmlEncode($r.BulbapediaSearch)
    $htmlOfficial=[System.Net.WebUtility]::HtmlEncode($r.OfficialSearch)
    $htmlTCGdex=[System.Net.WebUtility]::HtmlEncode($r.TCGdexCard)
    [void]$htmlRows.Add('<tr><td><code>'+$htmlId+'</code></td><td>'+$htmlName+'</td><td>'+$htmlSet+'</td><td>'+$htmlNum+'</td><td><a href="'+$htmlSite+'" target="_blank" rel="noopener">PkmnCards</a> | <a href="'+$htmlWeb+'" target="_blank" rel="noopener">Web search</a> | <a href="'+$htmlLimitless+'" target="_blank" rel="noopener">Limitless</a> | <a href="'+$htmlBulba+'" target="_blank" rel="noopener">Bulbapedia</a> | <a href="'+$htmlOfficial+'" target="_blank" rel="noopener">Official</a> | <a href="'+$htmlTCGdex+'" target="_blank" rel="noopener">TCGdex</a></td></tr>')
  }
  $htmlPage=@'
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pokemon missing English artwork review</title>
<style>body{font:15px system-ui,sans-serif;max-width:1400px;margin:2rem auto;padding:0 1rem;line-height:1.5;color:#20212a}table{border-collapse:collapse;width:100%}th,td{text-align:left;border-bottom:1px solid #ddd;padding:8px}th{position:sticky;top:0;background:#fff}tr:nth-child(even){background:#f5f7fa}code{font-size:12px}a{color:#1758ba}p{max-width:950px}</style></head><body>
<h1>English artwork review</h1><p>These exact printings are missing image links. Select the matching <strong>English set and collector number</strong> on PkmnCards, and confirm the artwork is the same printing. Copy a permitted <strong>direct HTTPS image URL</strong> to the <code>image-overrides.csv</code> file in the updater folder (columns: <code>TCGdexId,ImageUrl</code>). Do not paste a product/page URL. Image links will be reused on future runs. PkmnCards, Limitless, Bulbapedia and the official site are discovery links only; review exact English set/collector number and host rules before using any image. The updater never scrapes these sites.</p>
<table><thead><tr><th>TCGdex ID</th><th>Name</th><th>English set</th><th>Number</th><th>Review links</th></tr></thead><tbody>
'@
  $htmlPage+=[string]::Join("`n",$htmlRows.ToArray())
  $htmlPage+='</tbody></table></body></html>'
  [System.IO.File]::WriteAllText($reviewHtml,$htmlPage,(New-Object System.Text.UTF8Encoding($false)))
  Log "Multi-source link-first review: $($reviewRows.Count) unmatched prints. CSV: $reviewFile"
  Log "Open the offline clickable review page: $reviewHtml"
  $missingReport=Join-Path $LogDir 'missing-English-artwork-ids.txt'
  if($missingIds.Count -gt 0){
    @($missingIds | Sort-Object -Unique) | Set-Content -LiteralPath $missingReport -Encoding UTF8
    Log "Missing exact-printing image links: $($missingIds.Count). Card entries preserved; report: $missingReport"
  }else{
    Set-Content -LiteralPath $missingReport -Value '' -Encoding UTF8
    Log 'All included printings have an image URL.'
  }
  $usedCodes=@{};foreach($e in $entries.Values){foreach($p in $e.prints){$usedCodes[$p.code]=$true}}
  Log "Stage 3/3: writing and validating XML ($($entries.Count) entries) ..."
  $file=Join-Path $Output '01.PokemonTCG.xml'
  $staging=$file+'.tmp'
  $settings=New-Object System.Xml.XmlWriterSettings
  $settings.Indent=$true;$settings.Encoding=New-Object System.Text.UTF8Encoding($false)
  $writer=[Xml.XmlWriter]::Create($staging,$settings)
  try{
    $writer.WriteStartDocument();$writer.WriteStartElement('cockatrice_carddatabase');$writer.WriteAttributeString('version','4')
    $writer.WriteStartElement('sets')
    foreach($code in @($usedCodes.Keys|Sort-Object)){
      $s=$setMap[$code];$writer.WriteStartElement('set');WriteNode $writer 'name' $code
      WriteNode $writer 'longname' ('Pokemon TCG | '+$s.name+' | '+$s.lang.ToUpperInvariant())
      WriteNode $writer 'settype' 'Pokemon TCG'
      if($s.date){WriteNode $writer 'releasedate' $s.date}
      $writer.WriteEndElement()
    }
    $writer.WriteEndElement();$writer.WriteStartElement('cards')
    $allEntries=@($entries.Values|Sort-Object name,first)
    $written=0
    foreach($e in $allEntries){
      $written++
      if($e.prints.Count -eq 0){continue}
      $writer.WriteStartElement('card')
      # Explicitly namespaced to prevent collision with existing MTG card names.
      WriteNode $writer 'name' ('PKM: '+$e.name+' ['+$e.first+']')
      WriteNode $writer 'text' $e.text
      $writer.WriteStartElement('prop');WriteNode $writer 'layout' 'normal'
      WriteNode $writer 'type' ('Pokemon TCG - '+$e.category)
      WriteNode $writer 'maintype' 'Pokemon TCG';$writer.WriteEndElement()
      foreach($p in @($e.prints | Sort-Object code,num)){
        $writer.WriteStartElement('set');$writer.WriteAttributeString('num',$p.num)
        if($p.url){$writer.WriteAttributeString('picurl',$p.url)}
        if($p.rarity){$writer.WriteAttributeString('rarity',$p.rarity)}
        $writer.WriteString($p.code);$writer.WriteEndElement()
      }
      WriteNode $writer 'tablerow' '2';$writer.WriteEndElement()
      if(($written % 1000) -eq 0 -or $written -eq $allEntries.Count){ProgressLine 'XML' $written $allEntries.Count 'writing'}
    }
    $writer.WriteEndElement();$writer.WriteEndElement();$writer.WriteEndDocument()
  }finally{$writer.Dispose()}
  # v2.5: Apply per-printing image links BEFORE XML validation and install.
  # This is URL POPULATION, not proof that remote images load or match artwork.
  $manifestPath=Join-Path $Base 'artwork-printing-overrides.csv'
  $coverageLog=Join-Path $LogDir 'v2.5-artwork-applied.csv'
  if(Test-Path -LiteralPath $manifestPath){
    $overlay=@{}
    foreach($row in @(Import-Csv -LiteralPath $manifestPath -Encoding UTF8)){
      $url=([string]$row.ImageUrl).Trim()
      $uri=$null
      if(-not [Uri]::TryCreate($url,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne 'https') { continue }
      $key=([string]$row.CardName)+'|'+([string]$row.SetCode)+'|'+([string]$row.SetNumber)+'|'+([string]$row.Occurrence)
      $overlay[$key]=$row
    }
    $doc=New-Object System.Xml.XmlDocument
    $doc.PreserveWhitespace=$true
    $doc.Load($staging)
    $applied=0
    $audit=New-Object 'System.Collections.Generic.List[object]'
    foreach($card in $doc.SelectNodes('/cockatrice_carddatabase/cards/card')){
      $cardName=([string]$card.SelectSingleNode('name').InnerText)
      $seen=@{}
      foreach($print in $card.SelectNodes('set')){
        $setCode=([string]$print.InnerText).Trim()
        $setNum=[string]$print.GetAttribute('num')
        $part=$setCode+'|'+$setNum
        if(-not $seen.ContainsKey($part)){$seen[$part]=0}
        $seen[$part]++
        $key=$cardName+'|'+$setCode+'|'+$setNum+'|'+$seen[$part]
        if($overlay.ContainsKey($key) -and -not $print.GetAttribute('picurl')){
          $row=$overlay[$key]
          [void]$print.SetAttribute('picurl',[string]$row.ImageUrl)
          $applied++
          $audit.Add([pscustomobject]@{CardName=$cardName;SetCode=$setCode;SetNum=$setNum;ImageUrl=$row.ImageUrl;Method=$row.Method})
        }
      }
    }
    if($applied -gt 0){
      $doc.Save($staging)
    }
    if($audit.Count){$audit | Export-Csv -LiteralPath $coverageLog -NoTypeInformation -Encoding UTF8}
    $stillEmpty=$doc.SelectNodes('/cockatrice_carddatabase/cards/card/set[not(@picurl) or @picurl=""]').Count
    Log "Artwork v2.5: added $applied printing-specific image URLs; still blank $stillEmpty."
    if($stillEmpty -gt 0){
      Log "WARNING: v2.5 has $stillEmpty printings not covered by existing overrides. New data or changed grouping needs a review."
    }
  }

  $check=New-Object Xml.XmlDocument;$check.Load($staging)
  $actualCards=$check.SelectNodes('/cockatrice_carddatabase/cards/card').Count
  $actualSets=$check.SelectNodes('/cockatrice_carddatabase/sets/set').Count
  $actualPrints=$check.SelectNodes('/cockatrice_carddatabase/cards/card/set').Count
  if($actualCards -lt 1 -or $actualPrints -lt $actualCards){throw 'XML validation failed: no cards or insufficient printings.'}
  $duplicateNames=@($check.SelectNodes('/cockatrice_carddatabase/cards/card/name')|ForEach-Object {$_.InnerText}|Group-Object|Where-Object {$_.Count -gt 1})
  if($duplicateNames.Count){throw 'XML validation failed: duplicate card names.'}
  if(Test-Path $file){Copy-Item -LiteralPath $file -Destination (Join-Path $Backups ('01.PokemonTCG-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.xml'))}
  Move-Item -LiteralPath $staging -Destination $file -Force
  Log "XML validated: $actualCards English mechanical entries, $actualSets English expansion sets, $actualPrints printings (image-linked where available)."
  if($BuildOnly -or $MaxCards -gt 0){Log "Build-only/test requested. XML: $file";exit 0}
  $target=Select-Target
  if(-not $target){Log "No installation selected. XML saved to $file";exit 0}
  if(-not (Test-Path -LiteralPath $target -PathType Container)){throw 'Destination folder does not exist; nothing installed.'}
  $dest=Join-Path $target '01.PokemonTCG.xml'
  if(Test-Path -LiteralPath $dest){
    Copy-Item -LiteralPath $dest -Destination (Join-Path $Backups ('InstalledPokemon-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.xml')) -ErrorAction Stop
  }
  $stage=Join-Path $target '01.PokemonTCG.xml.new'
  Copy-Item -LiteralPath $file -Destination $stage -Force
  $installed=New-Object Xml.XmlDocument;$installed.Load($stage)
  Move-Item -LiteralPath $stage -Destination $dest -Force
  Set-Content -LiteralPath (Join-Path $Base 'pokemon-location.txt') -Value $target -Encoding UTF8
  Log "SUCCESS: installed $dest"
  Log 'Restart Cockatrice. Card Database > Manage Sets to enable Pokemon sets.'
  exit 0
}catch{
  Log "FAILED: $_"
  Write-Host $_.ScriptStackTrace
  exit 1
}

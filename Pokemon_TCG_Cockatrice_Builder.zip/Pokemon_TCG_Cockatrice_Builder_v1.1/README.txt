POKEMON TCG COCKATRICE XML BUILDER v1.3 — ENGLISH ONLY / CACHE FIX
========================================================
This replaces the multilingual edition. English card rules, English printings,
and English artwork ONLY. Multiple English art printings are grouped under
matching mechanical cards; cards with different attacks/HP stay separate.

RUN:
  0-Update-Pokemon.bat           Full build + install after target selection
  1-Test-First-30-Cards.bat      Generate 30-card sample; never installs
  2-Build-XML-Only.bat          Full XML into Output, no install

The builder uses TCGdex English card indexes and details. It does NOT request
French, Spanish, Japanese, or other non-English catalog endpoints.

IMPORTANT AFTER PREVIOUS MULTILINGUAL INSTALL:
  The updater replaces only its own 01.PokemonTCG.xml in the selected
  Cockatrice customsets directory, after backing up the previous file.
  If you installed other Pokemon XML files under different filenames, those
  are not automatically removed. Disable/remove those manually in Cockatrice.
  Restart Cockatrice and review Card Database > Manage Sets to disable any
  stale set selections. English-only set IDs begin with PKEN.

CACHE/RESUME:
  Keep your previous Cache directory. English caches (index-sets-en.json,
  index-cards-en.json, en-card-*.json) are reused; foreign-language cache
  files are simply ignored. Do not delete them while the old process runs.
  A fresh install can create a Cache folder on demand.

OUTPUT: Output\01.PokemonTCG.xml
INSTALL: Select your active Cockatrice customsets directory when prompted.
  Portable and installed clients are supported by the directory selector.
  Previous install target is remembered in pokemon-location.txt.
  The regular Magic cards.xml and tokens.xml are never overwritten.

ERROR HANDLING:
  On missing card details the process stops without installing an incomplete
  XML. Previous Pokemon output/installed XML is preserved or backed up.
  Logs are written under Logs, backup XML files under Backups.

NOTE: This release was inspected and packaged on Linux. The complete
Windows PowerShell + live TCGdex update was not executed here.

V1.3 FIX:
  PowerShell 5.1 could parse a valid array cache as one nested array, causing
  'en sets=1 indexCards=1' and a failed build. Now indexes are flattened,
  validated against reasonable minimum counts, and the index caches are
  automatically refreshed once if invalid. Existing en-card-*.json caches
  are left untouched. Malformed indexes are renamed .invalid-TIMESTAMP.
  Copy this package's BAT/PS1 files OVER your previous folder; KEEP Cache.

V1.3.1 OPTIONAL CLEANUP:
  Run 3-Clean-Non-English-Cache.bat after the English-only build succeeds.
  It asks for DELETE and removes only non-English index-sets/index-cards
  cache JSONs. All en-card-* and English indexes are preserved.

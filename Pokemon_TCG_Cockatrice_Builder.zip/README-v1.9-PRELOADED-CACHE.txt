POKEMON BUILDER v1.9 - PRELOADED CACHE + OFFLINE IMAGE REUSE
============================================================
This archive includes the 23,912 English card-detail JSON cache files supplied
from Output(1).zip, plus English index files and successful/failed external
artwork lookup records. These are JSON metadata, not downloaded image binaries.

WHAT IS CHANGED
* Fix cached indexes stored as {"value":[...],"Count":N} from older builds.
  The updater no longer mistakes these for one card/set and redownloads.
* Reuse exact-mechanical matching artwork already present in a different
  English printing. No names-only matches, no card/printing deletions.
* Preserve source quarantine, PkmnCards manual review, progress bars and API timeouts.
* Produce Logs/borrowed-artwork-report.csv for all image substitutions.

INSTALLATION
1. Extract this whole ZIP into a new folder, or over your existing builder.
2. Do NOT delete your original Cache, image-overrides.csv or pokemon-location.txt.
3. To retain custom entries: if you have added overrides to image-overrides.csv,
   keep your original overrides file when replacing scripts.
4. Run 2-Build-XML-Only.bat first to verify before installing in Cockatrice,
   or 0-Update-Pokemon.bat to build and optionally install.

CAVEATS
- Cached records are snapshots; new cards still require TCGdex internet calls.
- The quarantined pokemontcg.io source remains disabled in the supplied cache.
  Use 5-Reset-Disabled-Artwork-Sources.bat only if you want to try it again.
- Some image URLs may become unavailable even if stored in the XML.
- PowerShell 5.1 runtime validation must be performed on Windows; package and
  cache JSON/XML structural checks were performed in the build environment.

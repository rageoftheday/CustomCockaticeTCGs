#requires -version 5.1
[CmdletBinding()]
param(
  [string]$CustomSetsPath = '',
  [ValidateSet('English')][string]$ArtLanguages='English',
  [int]$MaxCards=0,
  [switch]$BuildOnly,
  [switch]$RefreshCache
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Base = Split-Path -Parent $MyInvocation.MyCommand.Path
$Cache = Join-Path $Base 'Cache'
$Output = Join-Path $Base 'Output'
$LogDir = Join-Path $Base 'Logs'
$Backups = Join-Path $Base 'Backups'
foreach($p in @($Cache,$Output,$LogDir,$Backups)){[void](New-Item -ItemType Directory -Path $p -Force)}
$LogFile = Join-Path $LogDir ((Get-Date -Format 'yyyyMMdd-HHmmss')+'.log')
function Log([string]$Message){$line=('[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'),$Message); Write-Host $line; Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8}
function JsonGet([string]$Url,[string]$CacheName,[int]$CacheHours=168){
  $file=Join-Path $Cache ($CacheName+'.json')
  if ((Test-Path -LiteralPath $file) -and -not $RefreshCache -and ((Get-Date)-(Get-Item -LiteralPath $file).LastWriteTime).TotalHours -lt $CacheHours){try{return (Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json)}catch{Remove-Item -LiteralPath $file -Force}}
  for($attempt=1;$attempt -le 4;$attempt++){
    try{
      $data=Invoke-RestMethod -Uri $Url -TimeoutSec 75 -Headers @{'User-Agent'='PokemonCockatriceXMLBuilder/1.3'}
      # An unavailable/empty language can legitimately return JSON null or an empty body.
      # PowerShell's Set-Content writes no file for null pipeline input.
      # Reject null BEFORE caching or attempting to move the temporary file.
      if ($null -eq $data) { throw "Empty/null API response (no cache file created)" }
      $json=ConvertTo-Json -InputObject $data -Depth 45 -Compress
      if ([string]::IsNullOrWhiteSpace($json) -or $json.Trim() -eq 'null') {
        throw "Empty/null JSON response (no cache file created)"
      }
      $tmp=$file+'.new'
      try {
        [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))
        if (-not (Test-Path -LiteralPath $tmp -PathType Leaf)) { throw "Temporary cache file was not written: $tmp" }
        Move-Item -LiteralPath $tmp -Destination $file -Force -ErrorAction Stop
      } finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
      }
      return $data
    }catch{
      if($attempt -eq 4){throw "API download failed: $Url : $_"}
      Start-Sleep -Seconds ($attempt*2)
    }
  }
}
# PowerShell 5.1 sometimes wraps cached JSON root arrays in one extra array.
# Normalize the API index shape to individual set/card objects before counting.
function Normalize-Index($InputValue) {
  $result = New-Object 'System.Collections.Generic.List[object]'
  foreach($entry in @($InputValue)) {
    if($null -eq $entry) { continue }
    if($entry -is [System.Array] -or $entry -is [System.Collections.IList]) {
      foreach($inner in $entry) { if($null -ne $inner) { [void]$result.Add($inner) } }
    } else {
      [void]$result.Add($entry)
    }
  }
  return $result.ToArray()
}
function Get-EnglishIndexes {
  # Preserve existing per-card caches; only refresh malformed/stale index files.
  $setIndex='index-sets-en'; $cardIndex='index-cards-en'
  for($pass=1;$pass -le 2;$pass++) {
    $setRaw=JsonGet 'https://api.tcgdex.net/v2/en/sets' $setIndex 12
    $cardRaw=JsonGet 'https://api.tcgdex.net/v2/en/cards' $cardIndex 12
    $sets=@(Normalize-Index $setRaw)
    $cards=@(Normalize-Index $cardRaw)
    if($sets.Count -ge 100 -and $cards.Count -ge 1000 -and (Val $sets[0] 'id') -and (Val $cards[0] 'id')) {
      return @{ sets=$sets; cards=$cards }
    }
    Log "WARN: English cache/index abnormal (sets=$($sets.Count), cards=$($cards.Count)); refusing partial XML."
    if($pass -eq 1) {
      foreach($key in @($setIndex,$cardIndex)) {
        $bad=Join-Path $Cache ($key+'.json')
        if(Test-Path -LiteralPath $bad) {
          Move-Item -LiteralPath $bad -Destination ($bad+'.invalid-'+(Get-Date -Format 'yyyyMMddHHmmss')) -Force
        }
      }
      Log 'Refreshing ONLY English indexes; downloaded en-card-* detail files will be preserved.'
    }
  }
  throw "English indexes are still incomplete after refreshing. Previous XML preserved."
}
function PathFor([string]$part){return [uri]::EscapeDataString($part)}
function Get-Candidates {
  $found=New-Object System.Collections.Generic.List[string]
  $local=@(
    (Join-Path $env:LOCALAPPDATA 'Cockatrice\Cockatrice\customsets'),
    (Join-Path $env:APPDATA 'Cockatrice\Cockatrice\customsets'),
    (Join-Path $env:LOCALAPPDATA 'Cockatrice\customsets'),
    (Join-Path $env:APPDATA 'Cockatrice\customsets'),
    (Join-Path $env:USERPROFILE 'AppData\Local\Cockatrice\Cockatrice\customsets'),
    (Join-Path $Base 'customsets'),(Join-Path $Base 'data\customsets'),
    (Join-Path (Split-Path $Base -Parent) 'data\customsets')
  )
  $ini=Join-Path $Base 'pokemon-location.txt'
  if(Test-Path $ini){$saved=(Get-Content $ini -Raw).Trim(); if($saved){$local=@($saved)+$local}}
  foreach($root in @($Base,(Split-Path $Base -Parent),$env:ProgramFiles,${env:ProgramFiles(x86)})){
    if($root -and (Test-Path $root)){
      foreach($rel in @('Cockatrice\data\customsets','Cockatrice\customsets','data\customsets')){$local+=Join-Path $root $rel}
    }
  }
  foreach($path in $local){if($path -and (Test-Path -LiteralPath $path -PathType Container)){
    try{$full=[IO.Path]::GetFullPath($path);if(-not $found.Contains($full)){$found.Add($full)}}catch{}
  }}
  return $found.ToArray()
}
function Select-Target {
  if($CustomSetsPath){return [IO.Path]::GetFullPath($CustomSetsPath)}
  $candidates=@(Get-Candidates)
  if($candidates.Count -gt 0){
    Log 'Detected possible customsets folders:'
    for($i=0;$i -lt $candidates.Count;$i++){Write-Host ('  [{0}] {1}' -f ($i+1),$candidates[$i])}
  }
  Write-Host '  [M] Manually choose a folder    [S] Save to Output only'
  $choice=Read-Host 'Select the actual Cockatrice customsets directory (Enter = 1 if found, otherwise M)'
  if($choice -eq 'S'){return ''}
  if($choice -eq 'M' -or $candidates.Count -eq 0){
    Add-Type -AssemblyName System.Windows.Forms
    $dlg=New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description='Choose Cockatrice customsets (Card Database > Open custom sets folder)'
    if($dlg.ShowDialog() -ne [Windows.Forms.DialogResult]::OK){throw 'No folder chosen. Nothing was installed.'}
    $selected=$dlg.SelectedPath
    if ((Split-Path $selected -Leaf) -ne 'customsets') {
      $confirmed=Read-Host "Selected folder is not named customsets. Install here anyway? Type YES"
      if($confirmed -cne 'YES'){throw 'Cancelled. Nothing was installed.'}
    }
    return $selected
  }
  if([string]::IsNullOrWhiteSpace($choice)){$choice='1'}
  $index=0
  if(-not [int]::TryParse($choice,[ref]$index) -or $index -lt 1 -or $index -gt $candidates.Count){throw 'Invalid selection.'}
  return $candidates[$index-1]
}
function Val($o,[string]$n){if($null -eq $o){return $null};$p=$o.PSObject.Properties[$n];if($p){return $p.Value};return $null}
function Txt($o){if($null -eq $o){return ''};return [string]$o}
function JoinItems($o){if($null -eq $o){return ''};return (@($o) | ForEach-Object {Txt $_}) -join ', '}
function MechanicalKey($c){
  # Exclude collector, rarity, art, illustrator and set. Include mechanics and English game wording.
  $name=Txt (Val $c 'name')
  $parts=New-Object System.Collections.Generic.List[string]
  $parts.Add($name)
  foreach($field in @('category','hp','types','stage','evolveFrom','suffix','trainerType','energyType','effect','retreat','weaknesses','resistances','regulationMark','description')){
    $v=Val $c $field
    if($null -ne $v){$parts.Add(($field+':'+($v|ConvertTo-Json -Depth 18 -Compress)))}
  }
  foreach($field in @('attacks','abilities')){
    $v=Val $c $field
    if($null -ne $v){$parts.Add(($field+':'+($v|ConvertTo-Json -Depth 18 -Compress)))}
  }
  return ($parts -join '|')
}
function DetailText($c){
  $lines=New-Object System.Collections.Generic.List[string]
  $category=Txt (Val $c 'category');$name=Txt (Val $c 'name')
  $lines.Add('Pokemon TCG | '+$category)
  foreach($field in @('hp','stage','evolveFrom','suffix','trainerType','energyType')){
    $v=Val $c $field
    if($v){$lines.Add(('{0}: {1}' -f $field,$v))}
  }
  $types=JoinItems (Val $c 'types');if($types){$lines.Add('Types: '+$types)}
  foreach($a in @(Val $c 'abilities')){
    if($null -eq $a){continue};$lines.Add('ABILITY: '+(Txt (Val $a 'name')))
    $type=Txt (Val $a 'type');if($type){$lines.Add('Type: '+$type)}
    $effect=Txt (Val $a 'effect');if($effect){$lines.Add($effect)}
  }
  foreach($a in @(Val $c 'attacks')){
    if($null -eq $a){continue};$lines.Add('ATTACK: '+(Txt (Val $a 'name')))
    $cost=JoinItems (Val $a 'cost');if($cost){$lines.Add('Cost: '+$cost)}
    $damage=Txt (Val $a 'damage');if($damage){$lines.Add('Damage: '+$damage)}
    $effect=Txt (Val $a 'effect');if($effect){$lines.Add($effect)}
  }
  $effect=Txt (Val $c 'effect');if($effect){$lines.Add('Effect: '+$effect)}
  foreach($field in @('weaknesses','resistances')){
    foreach($v in @(Val $c $field)){
      if($null -eq $v){continue};$lines.Add(('{0}: {1} {2}' -f $field,(Txt (Val $v 'type')),(Txt (Val $v 'value'))))
    }
  }
  $retreat=Val $c 'retreat';if($null -ne $retreat){$lines.Add('Retreat Cost: '+$retreat)}
  return ($lines -join "`n")
}
function SetCode([string]$language,[string]$setid){
  # Stable set IDs. English-only edition.
  $raw=$language.ToUpperInvariant()+'|'+$setid
  $sha=[Security.Cryptography.SHA1]::Create()
  try{$bytes=[Text.Encoding]::UTF8.GetBytes($raw);$hash=[BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','').Substring(0,9)}finally{$sha.Dispose()}
  return 'PK'+$language.ToUpperInvariant().Replace('-','')+$hash
}
function WriteNode($writer,[string]$tag,[string]$value){$writer.WriteElementString($tag,$value)}
try{
  Log 'Pokemon Cockatrice XML updater v1.3 | English wording | English printings and artwork only'
  $languages=@('en')
  $setMap=@{};$imageMap=@{};$englishCards=@{}
  foreach($lang in $languages){
    Log "Loading $lang set/card indexes ..."
    try{
      $indexes=Get-EnglishIndexes
      $sets=@($indexes.sets)
      $cards=@($indexes.cards)
    }catch{
      if($lang -eq 'en'){throw}
      Log "WARN: $lang index failed; skipping language: $_";continue
    }
    if($sets.Count -eq 0 -or $cards.Count -eq 0){
      if($lang -eq 'en'){throw 'English catalog is empty. Existing XML untouched.'}
      Log "SKIP: $lang has no published sets/cards; continuing with other languages."
      continue
    }
    foreach($set in $sets){
      $sid=Txt (Val $set 'id');if(-not $sid){continue}
      $code=SetCode $lang $sid
      $setMap[$code]=@{id=$sid;lang=$lang;name=(Txt (Val $set 'name'));date=(Txt (Val $set 'releaseDate'))}
    }
    foreach($card in $cards){
      $id=Txt (Val $card 'id');$image=Txt (Val $card 'image')
      if(-not $id){continue}
      $local=Txt (Val $card 'localId')
      if($image){$imageMap[$lang+'|'+$id]=@{image=$image.TrimEnd('/')+'/high.png';local=$local}}
      if($lang -eq 'en'){$englishCards[$id]=$card}
    }
    Log "$lang sets=$($sets.Count) indexCards=$($cards.Count) imageLinks=$((@($cards|Where-Object {$_.image})).Count)"
  }
  if($englishCards.Count -eq 0){throw 'English index empty; refusing to create an empty database.'}
  $ids=@($englishCards.Keys | Sort-Object)
  if($MaxCards -gt 0){$ids=@($ids|Select-Object -First $MaxCards);Log "TEST LIMIT: processing $($ids.Count) English cards"}
  $entries=@{};$loaded=0;$failed=New-Object System.Collections.Generic.List[string]
  foreach($id in $ids){
    try{$c=JsonGet ("https://api.tcgdex.net/v2/en/cards/"+(PathFor $id)) ('en-card-'+([Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($id)).TrimEnd('=').Replace('/','_').Replace('+','-')))}
    catch{$failed.Add($id);Log "WARN: card $id failed: $_";continue}
    if(-not (Val $c 'name')){$failed.Add($id);continue}
    $key=MechanicalKey $c
    if(-not $entries.ContainsKey($key)){
      $entries[$key]=@{name=(Txt (Val $c 'name'));text=(DetailText $c);category=(Txt (Val $c 'category'));first=$id;prints=(New-Object System.Collections.ArrayList)}
    }
    $group=$entries[$key]
    $sid=Txt (Val (Val $c 'set') 'id')
    if(-not $sid){$sid=($id -split '-')[0]}
    $local=Txt (Val $c 'localId')
    $rarity=Txt (Val $c 'rarity')
    foreach($lang in $languages){
      $mapkey=$lang+'|'+$id
      if(-not $imageMap.ContainsKey($mapkey)){continue}
      $code=SetCode $lang $sid
      if(-not $setMap.ContainsKey($code)){continue}
      $pic=$imageMap[$mapkey]
      $number=$pic.local;if(-not $number){$number=$local}
      [void]$group.prints.Add(@{code=$code;num=$number;url=$pic.image;rarity=$rarity;id=$lang+'|'+$id})
    }
    # Preserve English source cards even when TCGdex does not provide an image.
    if(-not $imageMap.ContainsKey('en|'+$id)){
      $code=SetCode 'en' $sid
      if($setMap.ContainsKey($code)){[void]$group.prints.Add(@{code=$code;num=$local;url='';rarity=$rarity;id='en|'+$id})}
    }
    $loaded++
    if(($loaded % 250) -eq 0){Log ("Fetched $loaded/$($ids.Count) card details; mechanics groups=$($entries.Count)")}
  }
  if($failed.Count -gt 0){
    $failFile=Join-Path $LogDir 'failed-card-ids.txt';$failed | Set-Content -LiteralPath $failFile -Encoding UTF8
    throw "$($failed.Count) card details failed. Cache retains successes; retry the updater. Existing XML untouched. See $failFile"
  }
  if($entries.Count -eq 0){throw 'No card entries produced.'}
  $usedCodes=@{};foreach($e in $entries.Values){foreach($p in $e.prints){$usedCodes[$p.code]=$true}}
  $file=Join-Path $Output '01.PokemonTCG.xml'
  $staging=$file+'.tmp'
  $settings=New-Object System.Xml.XmlWriterSettings
  $settings.Indent=$true;$settings.Encoding=New-Object System.Text.UTF8Encoding($false)
  $writer=[Xml.XmlWriter]::Create($staging,$settings)
  try{
    $writer.WriteStartDocument();$writer.WriteStartElement('cockatrice_carddatabase');$writer.WriteAttributeString('version','4')
    $writer.WriteStartElement('sets')
    foreach($code in @($usedCodes.Keys|Sort-Object)){
      $s=$setMap[$code];$writer.WriteStartElement('set');WriteNode $writer 'name' $code
      WriteNode $writer 'longname' ('Pokemon TCG | '+$s.name+' | '+$s.lang.ToUpperInvariant())
      WriteNode $writer 'settype' 'Pokemon TCG'
      if($s.date){WriteNode $writer 'releasedate' $s.date}
      $writer.WriteEndElement()
    }
    $writer.WriteEndElement();$writer.WriteStartElement('cards')
    $allEntries=@($entries.Values|Sort-Object name,first)
    foreach($e in $allEntries){
      if($e.prints.Count -eq 0){continue}
      $writer.WriteStartElement('card')
      # Explicitly namespaced to prevent collision with existing MTG card names.
      WriteNode $writer 'name' ('PKM: '+$e.name+' ['+$e.first+']')
      WriteNode $writer 'text' $e.text
      $writer.WriteStartElement('prop');WriteNode $writer 'layout' 'normal'
      WriteNode $writer 'type' ('Pokemon TCG - '+$e.category)
      WriteNode $writer 'maintype' 'Pokemon TCG';$writer.WriteEndElement()
      foreach($p in @($e.prints | Sort-Object code,num)){
        $writer.WriteStartElement('set');$writer.WriteAttributeString('num',$p.num)
        if($p.url){$writer.WriteAttributeString('picurl',$p.url)}
        if($p.rarity){$writer.WriteAttributeString('rarity',$p.rarity)}
        $writer.WriteString($p.code);$writer.WriteEndElement()
      }
      WriteNode $writer 'tablerow' '2';$writer.WriteEndElement()
    }
    $writer.WriteEndElement();$writer.WriteEndElement();$writer.WriteEndDocument()
  }finally{$writer.Dispose()}
  $check=New-Object Xml.XmlDocument;$check.Load($staging)
  $actualCards=$check.SelectNodes('/cockatrice_carddatabase/cards/card').Count
  $actualSets=$check.SelectNodes('/cockatrice_carddatabase/sets/set').Count
  $actualPrints=$check.SelectNodes('/cockatrice_carddatabase/cards/card/set').Count
  if($actualCards -lt 1 -or $actualPrints -lt $actualCards){throw 'XML validation failed: no cards or insufficient printings.'}
  $duplicateNames=@($check.SelectNodes('/cockatrice_carddatabase/cards/card/name')|ForEach-Object {$_.InnerText}|Group-Object|Where-Object {$_.Count -gt 1})
  if($duplicateNames.Count){throw 'XML validation failed: duplicate card names.'}
  if(Test-Path $file){Copy-Item -LiteralPath $file -Destination (Join-Path $Backups ('01.PokemonTCG-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.xml'))}
  Move-Item -LiteralPath $staging -Destination $file -Force
  Log "XML validated: $actualCards English mechanical entries, $actualSets English expansion sets, $actualPrints printings (image-linked where available)."
  if($BuildOnly -or $MaxCards -gt 0){Log "Build-only/test requested. XML: $file";exit 0}
  $target=Select-Target
  if(-not $target){Log "No installation selected. XML saved to $file";exit 0}
  if(-not (Test-Path -LiteralPath $target -PathType Container)){throw 'Destination folder does not exist; nothing installed.'}
  $dest=Join-Path $target '01.PokemonTCG.xml'
  if(Test-Path -LiteralPath $dest){
    Copy-Item -LiteralPath $dest -Destination (Join-Path $Backups ('InstalledPokemon-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.xml')) -ErrorAction Stop
  }
  $stage=Join-Path $target '01.PokemonTCG.xml.new'
  Copy-Item -LiteralPath $file -Destination $stage -Force
  $installed=New-Object Xml.XmlDocument;$installed.Load($stage)
  Move-Item -LiteralPath $stage -Destination $dest -Force
  Set-Content -LiteralPath (Join-Path $Base 'pokemon-location.txt') -Value $target -Encoding UTF8
  Log "SUCCESS: installed $dest"
  Log 'Restart Cockatrice. Card Database > Manage Sets to enable Pokemon sets.'
  exit 0
}catch{
  Log "FAILED: $_"
  Write-Host $_.ScriptStackTrace
  exit 1
}

#requires -version 5.1
<#
.SYNOPSIS
  Download the NeuroScape Genesis card catalog, convert art to JPG,
  and build a Cockatrice v4 custom XML set.
.EXAMPLE
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Build-Neuroscape-Cockatrice.ps1
.EXAMPLE
  .\Build-Neuroscape-Cockatrice.ps1 -OutputFolder 'D:\Neuroscape' -Install
.NOTES
  Uses the community Deckscape catalog for per-card metadata and official art links.
  Source cards/art remain copyright of their respective owners. Personal use only.
  ImageMagick is needed to convert WebP artwork into genuine JPG images.
#>
[CmdletBinding()]
param(
  [string]$OutputFolder = (Join-Path $env:USERPROFILE 'Downloads\Neuroscape_Cockatrice'),
  [switch]$Install,
  [switch]$SkipImages,
  [int]$DelayMilliseconds = 125,
  [switch]$NoAutoInstallImageMagick
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$rootUrl = 'https://www.deckscape.run'
$directoryUrl = "$rootUrl/cards/index"
$setCode = 'NSCP'
$imagesDir = Join-Path $OutputFolder 'Images_JPG'
$sourceDir = Join-Path $OutputFolder 'Source_WebP'
$xmlPath = Join-Path $OutputFolder '01.NeuroScape_Genesis.xml'
$csvPath = Join-Path $OutputFolder 'Neuroscape_Card_Report.csv'
$errorsPath = Join-Path $OutputFolder 'Neuroscape_Errors.txt'
New-Item -ItemType Directory -Force -Path $OutputFolder,$imagesDir,$sourceDir | Out-Null
$errors = [System.Collections.Generic.List[string]]::new()
$cards = [System.Collections.Generic.List[object]]::new()
$webParams = @{ UseBasicParsing = $true; TimeoutSec = 60; Headers = @{ 'User-Agent' = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36' } }

function Get-Page([string]$uri) {
  for ($attempt=1; $attempt -le 3; $attempt++) {
    try { return (Invoke-WebRequest -Uri $uri @webParams).Content }
    catch { if ($attempt -eq 3) { throw }; Start-Sleep -Seconds ($attempt*2) }
  }
}
function Html-Plain([string]$html) {
  $s = [regex]::Replace($html, '(?is)<(script|style|svg)\b[^>]*>.*?</\1>', ' ')
  $s = [regex]::Replace($s, '(?i)<br\s*/?>|</(?:p|div|h1|h2|h3|li|dt|dd|section|header|main|span)>', "`n")
  $s = [regex]::Replace($s, '<[^>]+>', ' ')
  $s = [System.Net.WebUtility]::HtmlDecode($s)
  $s = [regex]::Replace($s, '[ \t\u00a0]+', ' ')
  $s = [regex]::Replace($s, '\s*\r?\n\s*', "`n")
  return $s
}
function Field-After([string]$plain, [string]$label) {
  $m = [regex]::Match($plain, '(?im)^\s*' + [regex]::Escape($label) + '\s*\r?\n\s*([^\r\n]+)')
  if ($m.Success) { return $m.Groups[1].Value.Trim() }
  return ''
}
function Number-Of([string]$value) {
  $m = [regex]::Match($value,'\d+')
  if ($m.Success) { return $m.Value }
  return ''
}
function Safe-CardFile([string]$name) {
  # Cockatrice uses corrected card names for matching local pictures.
  $name = $name -replace '//','' -replace '/',' '
  $name = [regex]::Replace($name, '[*<>:"\\?\x00-\x1F]', '')
  $name = $name.Trim().TrimEnd('.')
  return $name
}
function Find-ArtUrl([string]$html) {
  $decoded = [System.Net.WebUtility]::HtmlDecode($html)
  $decoded = [regex]::Replace($decoded, '\\u0026', '&')
  $decoded = $decoded -replace '\\/', '/'
  $decoded = [uri]::UnescapeDataString($decoded)
  # Supabase links expose the actual full card rather than thumbnails.
  $m = [regex]::Match($decoded, 'https?://[^"''\s<>]+?/storage/v1/object/public/card-art/[^"''\s<>?]+?\.(?:webp|png|jpe?g)', 'IgnoreCase')
  if ($m.Success) { return $m.Value }
  return ''
}
function Get-Magick {
  $cmd = Get-Command magick.exe -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  $locations = @(
    "$env:ProgramFiles\ImageMagick-*\magick.exe",
    "${env:ProgramFiles(x86)}\ImageMagick-*\magick.exe",
    "$env:LOCALAPPDATA\Programs\ImageMagick-*\magick.exe"
  )
  foreach ($pattern in $locations) {
    $found = @(Get-Item -Path $pattern -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ($found.Count) { return $found[0].FullName }
  }
  return ''
}

$magick = ''
if (-not $SkipImages) {
  $magick = Get-Magick
  if (-not $magick -and -not $NoAutoInstallImageMagick -and (Get-Command winget.exe -ErrorAction SilentlyContinue)) {
    Write-Host 'ImageMagick not found. Attempting automatic installation through winget...'
    & winget.exe install --id ImageMagick.ImageMagick -e --accept-package-agreements --accept-source-agreements --silent
    $magick = Get-Magick
  }
  if (-not $magick) {
    throw 'ImageMagick is required for WebP to JPG conversion. Run: winget install ImageMagick.ImageMagick ; then rerun this script.'
  }
}

Write-Host "Reading $directoryUrl ..."
$directory = Get-Page $directoryUrl
# Exactly one UUID per card-detail URL; no reliance on JS pagination.
$matchesFound = [regex]::Matches($directory, '(?i)(?:href=["''])(?:https?://(?:www\.)?deckscape\.run)?/cards/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})')
$ids = [System.Collections.Generic.List[string]]::new()
$seen = @{}
foreach ($m in $matchesFound) {
  $id = $m.Groups[1].Value.ToLowerInvariant()
  if (-not $seen.ContainsKey($id)) { $seen[$id] = $true; $ids.Add($id) }
}
if ($ids.Count -lt 200) {
  throw "Only found $($ids.Count) card links in directory (expected about 256). Not creating a partial set. Site layout may have changed."
}
Write-Host "Found $($ids.Count) card detail pages."

$index = 0
foreach ($id in $ids) {
  $index++
  $url = "$rootUrl/cards/$id"
  Write-Progress -Activity 'Downloading NeuroScape Genesis cards' -Status "$index of $($ids.Count)" -PercentComplete ([int](100*$index/$ids.Count))
  try {
    $html = Get-Page $url
    $titleMatch = [regex]::Match($html, '(?is)<h1\b[^>]*>(.*?)</h1>')
    if (-not $titleMatch.Success) { throw 'Missing card title h1' }
    $name = (Html-Plain $titleMatch.Groups[1].Value).Trim()
    if (-not $name) { throw 'Empty card title' }
    $plain = Html-Plain $html
    $num = Number-Of (Field-After $plain 'Set / printing')
    $rarity = (Field-After $plain 'Rarity').ToLowerInvariant()
    $ram = Number-Of (Field-After $plain 'RAM cost')
    $attack = Number-Of (Field-After $plain 'Attack')
    $defence = Number-Of (Field-After $plain 'Defence')
    if (-not $num) { throw "Card number missing for $name" }
    if ($rarity -notin @('common','uncommon','rare','quantum rare','basic')) { $rarity = 'common' }
    if (-not $ram) { $ram = '0' }
    $mType = [regex]::Match($plain, '(?im)^\s*' + [regex]::Escape($name) + '\s*\r?\n\s*([^\r\n]+)')
    $typeLine = if ($mType.Success) { $mType.Groups[1].Value } else { '' }
    $gameType = if ($typeLine -match '(?i)mainframe') { 'Mainframe' } elseif ($typeLine -match '(?i)character') { 'Character' } elseif ($typeLine -match '(?i)gear|weapon|cyberware|tether') { 'Gear' } elseif ($typeLine -match '(?i)ram') { 'RAM' } else { 'Program' }
    # Text sits between the type/faction heading and the eBay entry.
    $ability = ''
    if ($mType.Success) {
      $start = $mType.Index + $mType.Length
      $following = $plain.Substring($start)
      $stop = [regex]::Match($following, '(?i)Find on eBay|Set / printing')
      if ($stop.Success) { $ability = $following.Substring(0,$stop.Index).Trim() }
      $ability = [regex]::Replace($ability, '\s+', ' ').Trim()
    }
    $artUrl = Find-ArtUrl $html
    if (-not $artUrl -and -not $SkipImages) { $errors.Add("ART LINK MISSING: $num $name ($url)") }
    $filename = (Safe-CardFile $name) + '_' + $setCode + '_' + $num + '.jpg'
    $jpgPath = Join-Path $imagesDir $filename
    $imageStatus = 'skipped'
    if (-not $SkipImages -and $artUrl) {
      if (Test-Path $jpgPath) { $imageStatus = 'existing' }
      else {
        $extension = [IO.Path]::GetExtension(($artUrl -split '\?')[0])
        $webpPath = Join-Path $sourceDir (("GEN-{0:D3}" -f [int]$num) + $extension)
        try {
          Invoke-WebRequest -Uri $artUrl -OutFile $webpPath @webParams
          & $magick $webpPath -auto-orient -background white -alpha remove -alpha off -quality 92 $jpgPath
          if ($LASTEXITCODE -ne 0 -or -not (Test-Path $jpgPath)) { throw "magick exited with $LASTEXITCODE" }
          $imageStatus = 'ok'
        } catch {
          $imageStatus = 'failed'
          $errors.Add("ART DOWNLOAD FAILED: $num $name - $($_.Exception.Message)")
          Remove-Item $jpgPath -Force -ErrorAction SilentlyContinue
        }
      }
    }
    $cards.Add([pscustomobject]@{
      Name=$name; Number=[int]$num; Rarity=$rarity; RAM=$ram; Type=$gameType;
      TypeDetail=$typeLine; Attack=$attack; Defence=$defence; Text=$ability;
      ImageURL=$artUrl; ImageFile=$filename; ImageStatus=$imageStatus; SourcePage=$url
    })
    Write-Host ("[{0}/{1}] {2,-34} #{3} {4}" -f $index,$ids.Count,$name,$num,$imageStatus)
  }
  catch { $errors.Add("CARD FAILED: $id - $($_.Exception.Message)"); Write-Warning "Card $index failed: $_" }
  if ($DelayMilliseconds -gt 0) { Start-Sleep -Milliseconds $DelayMilliseconds }
}
Write-Progress -Activity 'Downloading NeuroScape Genesis cards' -Completed
$ordered = @($cards | Sort-Object Number)
if (-not $ordered.Count) { throw 'No card data retrieved.' }
$duplicates = @($ordered | Group-Object Number | Where-Object Count -gt 1)
foreach ($d in $duplicates) { $errors.Add("DUPLICATE NUMBER: $($d.Name)") }
if ($duplicates.Count -gt 0) { throw 'Duplicate collector numbers found. XML not written. Check report.' }

$settings = [System.Xml.XmlWriterSettings]::new()
$settings.Indent = $true
$settings.Encoding = [System.Text.UTF8Encoding]::new($false)
$writer = [System.Xml.XmlWriter]::Create($xmlPath,$settings)
try {
  $writer.WriteStartDocument()
  $writer.WriteStartElement('cockatrice_carddatabase'); $writer.WriteAttributeString('version','4')
  $writer.WriteStartElement('sets')
  $writer.WriteStartElement('set')
  $writer.WriteElementString('name',$setCode)
  $writer.WriteElementString('longname','NeuroScape - Genesis')
  $writer.WriteElementString('settype','Custom')
  $writer.WriteEndElement(); $writer.WriteEndElement()
  $writer.WriteStartElement('cards')
  foreach ($c in $ordered) {
    $writer.WriteStartElement('card')
    $writer.WriteElementString('name',$c.Name)
    $writer.WriteStartElement('set')
    $writer.WriteAttributeString('rarity',$c.Rarity)
    $writer.WriteAttributeString('num',[string]$c.Number)
    if ($c.ImageURL) { $writer.WriteAttributeString('picurl',$c.ImageURL) }
    $writer.WriteString($setCode)
    $writer.WriteEndElement()
    $writer.WriteStartElement('prop')
    $writer.WriteElementString('colors','')
    $writer.WriteElementString('manacost',[string]$c.RAM)
    $writer.WriteElementString('cmc',[string]$c.RAM)
    $writer.WriteElementString('type',$c.Type)
    $writer.WriteElementString('maintype',$c.Type)
    if ($c.Attack -ne '' -and $c.Defence -ne '') { $writer.WriteElementString('pt',"$($c.Attack)/$($c.Defence)") }
    $writer.WriteEndElement()
    $writer.WriteElementString('tablerow',$(if ($c.Type -eq 'Mainframe') {'0'} elseif ($c.Type -eq 'Character') {'1'} elseif ($c.Type -eq 'Gear') {'2'} else {'3'}))
    $rules = $c.Text
    if ($c.TypeDetail) { $rules = "[$($c.TypeDetail)] " + $rules }
    $writer.WriteElementString('text',$rules.Trim())
    $writer.WriteEndElement()
  }
  $writer.WriteEndElement(); $writer.WriteEndElement(); $writer.WriteEndDocument()
} finally { $writer.Dispose() }
# Verify that generated XML can be loaded.
[xml]$checkXml = Get-Content -LiteralPath $xmlPath -Raw -Encoding UTF8
if ($checkXml.cockatrice_carddatabase.cards.card.Count -ne $ordered.Count) { throw 'XML card-count verification failed.' }
$ordered | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
@($errors) | Set-Content -LiteralPath $errorsPath -Encoding UTF8

if ($Install) {
  # Cockatrice paths can be customized; these are the usual Windows defaults.
  $appDataBase = Join-Path $env:LOCALAPPDATA 'Cockatrice\Cockatrice'
  $customsets = Join-Path $appDataBase 'customsets'
  $custompics = Join-Path $appDataBase 'pics\CUSTOM\Neuroscape'
  New-Item -ItemType Directory -Path $customsets,$custompics -Force | Out-Null
  Copy-Item -LiteralPath $xmlPath -Destination (Join-Path $customsets (Split-Path $xmlPath -Leaf)) -Force
  Get-ChildItem -LiteralPath $imagesDir -Filter '*.jpg' | Copy-Item -Destination $custompics -Force
  Write-Host "Installed to default Cockatrice paths. Confirm these match Settings > General > Directories."
}
$failedCards = @($errors | Where-Object { $_ -like 'CARD FAILED:*' }).Count
$imagesDone = @($ordered | Where-Object { $_.ImageStatus -in @('ok','existing') }).Count
Write-Host ''
Write-Host '============== COMPLETE ==============' -ForegroundColor Cyan
Write-Host "Card entries: $($ordered.Count) / $($ids.Count)"
Write-Host "JPG images:   $imagesDone / $($ordered.Count)"
Write-Host "Card failures: $failedCards; total warnings: $($errors.Count)"
Write-Host "XML:          $xmlPath"
Write-Host "JPG folder:   $imagesDir"
Write-Host "CSV report:   $csvPath"
Write-Host "Error report: $errorsPath"
if (-not $Install) { Write-Host 'To copy files into Cockatrice automatically, rerun with -Install.' }
if ($ordered.Count -lt $ids.Count -or ($imagesDone -lt $ordered.Count -and -not $SkipImages)) { Write-Warning 'The export is incomplete. See Neuroscape_Errors.txt.' }

POKEMON BUILDER v1.8 - AUTOMATIC ARTWORK SOURCE QUARANTINE

If a secondary artwork provider gives HTTP 429, HTTP 5xx, a timeout or a
network/connectivity error, the updater immediately stops making new live
requests to THAT provider. It saves the disabled provider in:
  Cache\artwork-disabled-sources.json

The disabled provider stays disabled across later update runs until you
explicitly reset it with:
  5-Reset-Disabled-Artwork-Sources.bat

The disabled source can still provide previously cached GOOD image URLs.
Verified manual image-overrides.csv and primary TCGdex images still work.
An individual card returning HTTP 404 does not disable an entire provider.

Progress logs will show the provider has been disabled. The other stages
continue; no existing card definitions or artwork are removed.

The 20-source shortlist is not 20 live APIs. This patch quarantines the
currently integrated pokemontcg.io provider. Other future adapters should
use the same per-provider quarantine logic.

Keep your existing Cache, image-overrides.csv and pokemon-location.txt.
Only scripts should be updated. Full Windows PowerShell execution remains
unverified in this environment.
